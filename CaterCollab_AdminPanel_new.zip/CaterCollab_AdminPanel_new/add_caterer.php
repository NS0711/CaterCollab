<?php
include 'db_connection.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form submission for adding new caterer
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    // Assuming form fields are named accordingly, modify if necessary
    $company_name = $_POST['company_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $line1_address = $_POST['line1_address'];
    $line2_address = $_POST['line2_address'];
    $postal_code = $_POST['postal_code'];
    $phn_no = $_POST['phn_no'];

    // Insert new caterer details into the database
    $insertSql = "INSERT INTO caterers (COMPANY_NAME, EMAIL, PASSWORD, LINE1_ADDRESS, LINE2_ADDRESS, POSTAL_CODE, PHN_NO) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertSql);
    $stmt->bind_param("sssssss", $company_name, $email, $password, $line1_address, $line2_address, $postal_code, $phn_no);

    if ($stmt->execute()) {
        // If insertion is successful, redirect to the caterer list page
        header("Location: caterer.php");
        exit();
    } else {
        echo "Error adding caterer: " . $conn->error;
    }
}


// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Caterer</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2>Add Caterer</h2>
    <form method="post">
        <div class="form-group">
            <label for="company_name">Company Name:</label>
            <input type="text" class="form-control" id="company_name" name="company_name" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <div class="form-group">
            <label for="line1_address">Line 1 Address:</label>
            <input type="text" class="form-control" id="line1_address" name="line1_address" required>
        </div>
        <div class="form-group">
            <label for="line2_address">Line 2 Address:</label>
            <input type="text" class="form-control" id="line2_address" name="line2_address">
        </div>
        <div class="form-group">
            <label for="postal_code">Postal Code:</label>
            <input type="text" class="form-control" id="postal_code" name="postal_code" required>
        </div>
        <div class="form-group">
            <label for="phn_no">Phone Number:</label>
            <input type="text" class="form-control" id="phn_no" name="phn_no" required>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
