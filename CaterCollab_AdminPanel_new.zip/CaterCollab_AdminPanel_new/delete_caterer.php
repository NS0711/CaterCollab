<?php
include 'db_connection.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if caterer ID is set in the URL
if(isset($_GET['id'])) {
    // Get the caterer ID from the URL
    $caterer_id = $_GET['id'];
    
    // Prepare and execute SQL statement to delete the caterer
    $deleteSql = "DELETE FROM caterers WHERE CATERER_ID = ?";
    $stmt = $conn->prepare($deleteSql);
    $stmt->bind_param("i", $caterer_id);
    $stmt->execute();
    $stmt->close();
    
    // Redirect to the page where the list of caterers is displayed
    header("Location: caterer.php");
    exit();
} else {
    // If caterer ID is not set in the URL, redirect to an error page or handle appropriately
    echo "Caterer ID not provided.";
}
?>
