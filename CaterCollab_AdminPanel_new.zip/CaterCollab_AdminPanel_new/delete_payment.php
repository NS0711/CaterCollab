<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if payment ID is provided in the URL
if(isset($_GET['id'])) {
    // Sanitize the input to prevent SQL injection
    $payment_id = mysqli_real_escape_string($conn, $_GET['id']);

    // Construct SQL DELETE statement
    $sql = "DELETE FROM payment WHERE PAYMENT_ID = $payment_id";

    // Execute the DELETE statement
    if ($conn->query($sql) === TRUE) {
        // If deletion is successful, redirect back to the payment list page
        header("Location: payment.php");
        exit();
    } else {
        echo "Error deleting payment: " . $conn->error;
    }
} else {
    // If no payment ID is provided, redirect back to the payment list page
    header("Location: payment.php");
    exit();
}

// Close the database connection
$conn->close();
?>
