<?php
include 'db_connection.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if order ID is provided in the URL
if(isset($_GET['id'])) {
    // Sanitize the input to prevent SQL injection
    $order_id = mysqli_real_escape_string($conn, $_GET['id']);

    // Retrieve order details from the database
    $sql = "SELECT * FROM orders WHERE ORDER_ID = $order_id";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $order = $result->fetch_assoc();
    } else {
        echo "Order not found.";
        exit();
    }
} else {
    echo "Order ID not provided.";
    exit();
}

// Process form submission for updating order details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    // Assuming form fields are named accordingly, modify if necessary
    $menu_id = $_POST['menu_id'];
    $caterer_id = $_POST['caterer_id'];
    $customer_id = $_POST['customer_id'];
    $order_items = $_POST['order_items'];
    $quantity = $_POST['quantity'];
    $total_amount = $_POST['total_amount'];
    $delivery_date_time = $_POST['delivery_date_time'];
    $delivery_location = $_POST['delivery_location'];

    // Update order details in the database
    $sql = "UPDATE orders SET MENU_ID = '$menu_id', CATERER_ID = '$caterer_id', CUSTOMER_ID = '$customer_id', ORDER_ITEMS = '$order_items', QUANTITY = '$quantity', TOTAL_AMOUNT = '$total_amount', DELIVERY_DATE_TIME = '$delivery_date_time', DELIVERY_LOCATION = '$delivery_location' WHERE ORDER_ID = $order_id";

    if ($conn->query($sql) === TRUE) {
        // If update is successful, redirect back to the order list page
        header("Location: order.php");
        exit();
    } else {
        echo "Error updating order: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2>Edit Order</h2>
    <form method="post">
        <div class="form-group">
            <label for="menu_id">Menu ID:</label>
            <input type="text" class="form-control" id="menu_id" name="menu_id" value="<?php echo $order['MENU_ID']; ?>">
        </div>
        <div class="form-group">
            <label for="caterer_id">Caterer ID:</label>
            <input type="text" class="form-control" id="caterer_id" name="caterer_id" value="<?php echo $order['CATERER_ID']; ?>">
        </div>
        <div class="form-group">
            <label for="customer_id">Customer ID:</label>
            <input type="text" class="form-control" id="customer_id" name="customer_id" value="<?php echo $order['CUSTOMER_ID']; ?>">
        </div>
        <div class="form-group">
            <label for="order_items">Order Items:</label>
            <input type="text" class="form-control" id="order_items" name="order_items" value="<?php echo $order['ORDER_ITEMS']; ?>">
        </div>
        <div class="form-group">
            <label for="quantity">Quantity:</label>
            <input type="text" class="form-control" id="quantity" name="quantity" value="<?php echo $order['QUANTITY']; ?>">
        </div>
        <div class="form-group">
            <label for="total_amount">Total Amount:</label>
            <input type="text" class="form-control" id="total_amount" name="total_amount" value="<?php echo $order['TOTAL_AMOUNT']; ?>">
        </div>
        <div class="form-group">
            <label for="delivery_date_time">Delivery Date & Time:</label>
            <input type="text" class="form-control" id="delivery_date_time" name="delivery_date_time" value="<?php echo $order['DELIVERY_DATE_TIME']; ?>">
        </div>
        <div class="form-group">
            <label for="delivery_location">Delivery Location:</label>
            <input type="text" class="form-control" id="delivery_location" name="delivery_location" value="<?php echo $order['DELIVERY_LOCATION']; ?>">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
