<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if menu ID is provided in the URL
if (isset($_GET['id'])) {
    $menu_id = $_GET['id'];
    
    // Retrieve menu details from the database using the ID
    $sql = "SELECT * FROM menus WHERE MENU_ID = $menu_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $menu = $result->fetch_assoc();
    } else {
        echo "Menu not found.";
        exit();
    }
} else {
    echo "Menu ID not provided.";
    exit();
}

// Handle form submission for updating menu details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $menu_list = $_POST["menu_list"];
    $company_name = $_POST["company_name"];
    $price = $_POST["price"];
    $image_url = $_POST["image_url"];
    $ratings = $_POST["ratings"];
    $updated_date = date("Y-m-d H:i:s"); // Get current date and time
    
    // Update menu details in the database
    $update_sql = "UPDATE menus SET 
        MENU_LIST='$menu_list', 
        COMPANY_NAME='$company_name', 
        PRICE='$price', 
        IMAGE_URL='$image_url', 
        RATINGS='$ratings', 
        UPDATED_DATE='$updated_date' 
        WHERE MENU_ID = $menu_id";
    
    if ($conn->query($update_sql) === TRUE) {
        echo "Manu details updated successfully.";
        header("Location: menu.php");
        exit();
    } else {
        echo "Error updating menu details: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Menu</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2>Edit Menu</h2>
    <form method="post" action="">
        <div class="form-group">
            <label for="menu_list">Menu List:</label>
            <textarea class="form-control" id="menu_list" name="menu_list"><?php echo isset($menu['MENU_LIST']) ? $menu['MENU_LIST'] : ''; ?></textarea>
        </div>
        <div class="form-group">
            <label for="company_name">Company Name:</label>
            <input type="text" class="form-control" id="company_name" name="company_name" value="<?php echo isset($menu['COMPANY_NAME']) ? $menu['COMPANY_NAME'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="price">Price:</label>
            <input type="text" class="form-control" id="price" name="price" value="<?php echo isset($menu['PRICE']) ? $menu['PRICE'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="image_url">Image URL:</label>
            <input type="text" class="form-control" id="image_url" name="image_url" value="<?php echo isset($menu['IMAGE_URL']) ? $menu['IMAGE_URL'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="ratings">Ratings:</label>
            <input type="text" class="form-control" id="ratings" name="ratings" value="<?php echo isset($menu['RATINGS']) ? $menu['RATINGS'] : ''; ?>">
        </div>
        <!-- Add more form fields as needed -->
        <button type="submit" class="btn btn-primary">Submit</button>
        <button href="menu.php" class="btn btn-primary">Back</button>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
