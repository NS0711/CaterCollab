<?php
include 'db_connection.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch caterers
function getCaterers($conn) {
    $sql = "SELECT * FROM caterers";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $caterers = [];
        while($row = $result->fetch_assoc()) {
            $caterers[] = $row;
        }
        return $caterers;
    } else {
        return [];
    }
}

function getTotalCaterers($conn) {
    $sql = "SELECT COUNT(*) as total FROM caterers";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        return $row['total'];
    } else {
        return 0;
    }
}

// Handle image upload
if(isset($_FILES["logo"]) && $_FILES["logo"]["error"] == 0) {
    $targetDir = "logo/";
    $targetFile = $targetDir . basename($_FILES["logo"]["name"]);
    if(move_uploaded_file($_FILES["logo"]["tmp_name"], $targetFile)) {
        // Assuming you have other form field values available
        // You need to populate the $data array with appropriate values
        $data = array(
            'company_name' => $_POST['company_name'],
            'email' => $_POST['email'],
            'password' => $_POST['password'],
            'line1_address' => $_POST['line1_address'],
            'line2_address' => $_POST['line2_address'],
            'postal_code' => $_POST['postal_code'],
            'phn_no' => $_POST['phn_no'],
             );

        // Prepare and execute the SQL statement to insert data into the database
        $insertSql = "INSERT INTO cater_db (COMPANY_NAME, EMAIL, PASSWORD, LINE1_ADDRESS, LINE2_ADDRESS, POSTAL_CODE, PHN_NO, LICENSE_INFO, RATINGS, CUSINE_TYPE, CANCELLATION_POLICY, MENU_LIST, LOGO_NAME) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertSql);
        $stmt->bind_param("sssssssssssss", $data['company_name'], $data['email'], $data['password'], $data['line1_address'], $data['line2_address'], $data['postal_code'], $data['phn_no'], $data['license_info'], $data['ratings'], $data['cusine_type'], $data['cancellation_policy'], $data['menu_list'], $data['logo_name']);
        $stmt->execute();
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caterers Management System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <style> 
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .container {
            margin-top: 20px;
        }
        #add{
            float: right;
            background-color: black;
            font-size: 15px;
            color: white;
            margin: 7px;
            padding: 7px;
            border-radius: 10px;
        }
        #header{
            font-size: 30px;
            padding: 10px;
            margin: 10px;
            display: flex;
            justify-content: space-between; /* Align items horizontally */
            align-items: center; /* Align items vertically */
        }
        #total-caterers {
        margin-top: 20px;
        font-size: 24px;
        background-color: #f8f9fa;
        padding: 10px 20px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    #total-caterers span {
        font-weight: bold;
        color: #333; /* Change color if needed */
    }
        #edit-del{
            color: black;
        }
        .caterer {
            margin-top: 20px;
        }
        .caterer {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }
        .caterer td, .caterer th {
            border: 1px solid #ddd;
            padding: 8px;
        }
        .caterer tr:nth-child(even){background-color: white;}
        .caterer tr:hover {background-color: darkgrey;}
        .caterer th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: black;
            color: white;
        }
        #backBtn {
            color: black;
            background-color: white;
            border-color: black;
        }
    </style>
</head>
<body>

<div class="customer">
    <div id="header">
        <a href="home.php" class="btn btn-primary" id="backBtn"><i class="fas fa-arrow-left"></i></a>
        <p>Caterers Management System</p>
        <a href='add_caterer.php'  id='add'>+ Add</a>
    </div>
    <div class="caterer">
        <!-- Display Caterers -->
        <div class="row">
            <div class="col-md-12">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Caterer ID</th>
                            <th>Company Name</th>
                            <th>Email</th>
                            <th>Password</th>
                            <th>Line1 Address</th>
                            <th>Line2 Address</th>
                            <th>Postal Code</th>
                            <th>Phn. no.</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Fetch caterers from the database
                        $caterers = getCaterers($conn);

                        // Check if caterers are fetched
                        if (!empty($caterers)) {
                            foreach ($caterers as $caterer) {
                                echo "<tr>";
                                echo "<td>{$caterer['CATERER_ID']}</td>";
                                echo "<td>{$caterer['COMPANY_NAME']}</td>";
                                echo "<td>{$caterer['EMAIL']}</td>";
                                echo "<td>{$caterer['PASSWORD']}</td>";
                                echo "<td>{$caterer['LINE1_ADDRESS']}</td>";
                                echo "<td>{$caterer['LINE2_ADDRESS']}</td>";
                                echo "<td>{$caterer['POSTAL_CODE']}</td>";
                                echo "<td>{$caterer['PHN_NO']}</td>";
                                echo "<td>";
                                echo "<a href='edit_caterer.php?id={$caterer['CATERER_ID']}'><i class='fas fa-edit' id='edit-del'></i></a>
                                    <a href='delete_caterer.php?id={$caterer['CATERER_ID']}'><i class='fas fa-trash-alt' id='edit-del'></i></a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='9'>No caterers found.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
                <?php
            // Display total number of customers
            $totalCaterers = getTotalCaterers($conn);
            echo "<p id='total-caterers'>Total CATERERS: $totalCaterers</p>";
            ?>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
