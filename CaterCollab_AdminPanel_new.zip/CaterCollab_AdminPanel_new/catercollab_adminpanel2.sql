-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2024 at 11:54 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `catercollab_adminpanel2`
--

-- --------------------------------------------------------

--
-- Table structure for table `caterers`
--

CREATE TABLE `caterers` (
  `CATERER_ID` int(11) NOT NULL,
  `COMPANY_NAME` varchar(50) DEFAULT NULL,
  `EMAIL` varchar(25) DEFAULT NULL,
  `PASSWORD` varchar(25) DEFAULT NULL,
  `PHN_NO` bigint(20) DEFAULT NULL,
  `LINE1_ADDRESS` varchar(50) DEFAULT NULL,
  `LINE2_ADDRESS` varchar(50) DEFAULT NULL,
  `CITY` varchar(20) DEFAULT NULL,
  `STATE` varchar(20) DEFAULT NULL,
  `POSTAL_CODE` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `caterers`
--

INSERT INTO `caterers` (`CATERER_ID`, `COMPANY_NAME`, `EMAIL`, `PASSWORD`, `PHN_NO`, `LINE1_ADDRESS`, `LINE2_ADDRESS`, `CITY`, `STATE`, `POSTAL_CODE`) VALUES
(13, 'savour', 'savour@123.com', '1234', 7874003288, 'paldi', 'shantivan', NULL, 'gujarat', 380007),
(14, 'ChefCater', 'chef@cater.com', '1234', 7874003228, 'Samarth complex', 'Naranpura', 'Ahmedabad', 'Gujarat', 380013);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `CUSTOMER_ID` int(11) NOT NULL,
  `NAME` varchar(50) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `PASSWORD` varchar(20) NOT NULL,
  `LINE1_ADDRESS` varchar(100) NOT NULL,
  `LINE2_ADDRESS` varchar(100) NOT NULL,
  `CITY` varchar(50) NOT NULL,
  `STATE` varchar(50) NOT NULL,
  `POSTAL_CODE` varchar(10) NOT NULL,
  `PHN_NO` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`CUSTOMER_ID`, `NAME`, `EMAIL`, `PASSWORD`, `LINE1_ADDRESS`, `LINE2_ADDRESS`, `CITY`, `STATE`, `POSTAL_CODE`, `PHN_NO`) VALUES
(1, 'Yashvi', 'yashvi@123.com', 'password123', '8 rajgiri', 'shantivan', 'Ahmedabad', 'Gujarat', '380007', 1234567890),
(3, 'shah', 'abcd@123.com', '1234', 'abc', 'abc', 'xyz', 'gujarat', '380013', 2147483647),
(5, 'yashvi shah', 'yashvi@123.com', '1234', 'darpan', 'naranpura', 'ahmedabad', 'gujarat', '380007', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `FEEDBACK_ID` int(11) NOT NULL,
  `ORDER_ID` int(11) DEFAULT NULL,
  `CATERER_ID` int(11) DEFAULT NULL,
  `CUSTOMER_ID` int(11) DEFAULT NULL,
  `CUSTOMER_RATINGS` float NOT NULL,
  `CUSTOMER_COMMENT` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FEEDBACK_ID`, `ORDER_ID`, `CATERER_ID`, `CUSTOMER_ID`, `CUSTOMER_RATINGS`, `CUSTOMER_COMMENT`) VALUES
(1, 1, 1, 1, 4.5, 'abc'),
(2, 1, 1, 3, 5, 'hy');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `MENU_ID` int(11) NOT NULL,
  `CATERER_ID` int(11) NOT NULL,
  `CATERING_TYPE` varchar(50) NOT NULL,
  `CATERING_CHARGES` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`MENU_ID`, `CATERER_ID`, `CATERING_TYPE`, `CATERING_CHARGES`) VALUES
(10, 13, 'Wedding', 6000.00),
(11, 13, 'Wedding', 6000.00),
(12, 13, 'Wedding', 6000.00),
(19, 13, 'Wedding', 6000.00),
(20, 14, 'Wedding', 5000.00),
(21, 14, 'Wedding', 5000.00),
(22, 13, 'Wedding', 6000.00);

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `MENU_ITEM_ID` int(11) NOT NULL,
  `MENU_ID` int(11) DEFAULT NULL,
  `ITEM_NAME` varchar(255) NOT NULL,
  `PRICE` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`MENU_ITEM_ID`, `MENU_ID`, `ITEM_NAME`, `PRICE`) VALUES
(8, 10, 'Lunch ', '600.00'),
(12, 20, 'Bhaji Pav', '350.00'),
(13, 10, 'Dinner ', '800.00'),
(14, 10, 'Pizza', '800.00'),
(15, 10, 'Pizza', '800.00');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `ORDER_ID` int(11) NOT NULL,
  `MENU_ID` int(11) DEFAULT NULL,
  `CATERER_ID` int(11) DEFAULT NULL,
  `CUSTOMER_ID` int(11) DEFAULT NULL,
  `ORDER_ITEMS` varchar(50) NOT NULL,
  `QUANTITY` varchar(50) NOT NULL,
  `TOTAL_AMOUNT` decimal(10,2) NOT NULL,
  `DELIVERY_DATE_TIME` datetime NOT NULL,
  `DELIVERY_LOCATION` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ORDER_ID`, `MENU_ID`, `CATERER_ID`, `CUSTOMER_ID`, `ORDER_ITEMS`, `QUANTITY`, `TOTAL_AMOUNT`, `DELIVERY_DATE_TIME`, `DELIVERY_LOCATION`) VALUES
(1, NULL, 1, 1, 'Pizza', '2', '20.00', '2024-03-20 12:00:00', '123 Main St');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `PAYMENT_ID` int(11) NOT NULL,
  `CUSTOMER_ID` int(11) DEFAULT NULL,
  `CATERER_ID` int(11) DEFAULT NULL,
  `ORDER_ID` int(11) DEFAULT NULL,
  `PAYMENT_METHOD` varchar(20) NOT NULL,
  `PAYMENT_DATE` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin'),
(13, 'shah', '$2y$10$EGoLi8GXeC6PZOt.Lo5PTe2WAvklKZLEMx4sYnHlXd7bU8p2Cdb2O'),
(14, 'shah', '$2y$10$bEZUxuOpJHJKwsVSB.Lkw.ofuwITH/LR4OBS0ZP2.pWJXRz/kymYq'),
(15, 'shah', '$2y$10$HSWYg3ebRCckbBLgWU5z6e02VdiZb55jFpOw0bI423k.MUSM6rTji'),
(16, 'shah', '$2y$10$k4VcI6AXN1ODs.hYykYXpe39bwPPiHRriSetvLK1lMyfvv/AlIYga'),
(17, 'shah', '$2y$10$BdpGTr.SXdIo.a9jJY62/evX.PQholD1FLRRPAEebfeQpz65qzWiS'),
(18, 'shah', '$2y$10$MYuXSS5JGRDrRpeCat8Juuq/4lrveIVA2A4vd/gE1YSTo0n8EoPbO'),
(19, 'shah', '$2y$10$KI0c7SAo96YqIgv1xOQz0e93v/C1H8kicM7KvosKCdMEmvDi7PyVG'),
(20, 'shah', '$2y$10$sagC7WC193MgAtgFSawPe.XM0pUWQ2AkIqB0HMt9wpaRHTI8UN9xq'),
(21, 'shah', '$2y$10$28ddmjCwPhYvEMHFYEIanuiD/aPmwNsZ3YdSkz62XUV.ezjrZ8H96'),
(22, 'yashvi', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `caterers`
--
ALTER TABLE `caterers`
  ADD PRIMARY KEY (`CATERER_ID`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`CUSTOMER_ID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`FEEDBACK_ID`),
  ADD KEY `fk_customer_id` (`CUSTOMER_ID`),
  ADD KEY `fk_order_id` (`ORDER_ID`),
  ADD KEY `fk_caterer_id` (`CATERER_ID`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`MENU_ID`),
  ADD KEY `fk_caterer_id_menu` (`CATERER_ID`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`MENU_ITEM_ID`),
  ADD KEY `fk_menu_id` (`MENU_ID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`ORDER_ID`),
  ADD KEY `fk_customer_id_order` (`CUSTOMER_ID`),
  ADD KEY `fk_caterer_id_order` (`CATERER_ID`),
  ADD KEY `fk_menu_id_order` (`MENU_ID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`PAYMENT_ID`),
  ADD KEY `fk_caterer_id_payment` (`CATERER_ID`),
  ADD KEY `fk_customer_id_pay` (`CUSTOMER_ID`),
  ADD KEY `fk_order_id_payment` (`ORDER_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `caterers`
--
ALTER TABLE `caterers`
  MODIFY `CATERER_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `CUSTOMER_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `FEEDBACK_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `MENU_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `MENU_ITEM_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `ORDER_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `PAYMENT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `fk_customer_id` FOREIGN KEY (`CUSTOMER_ID`) REFERENCES `customers` (`CUSTOMER_ID`);

--
-- Constraints for table `menus`
--
ALTER TABLE `menus`
  ADD CONSTRAINT `fk_caterer_id_menu` FOREIGN KEY (`CATERER_ID`) REFERENCES `caterers` (`CATERER_ID`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_customer_id_order` FOREIGN KEY (`CUSTOMER_ID`) REFERENCES `customers` (`CUSTOMER_ID`),
  ADD CONSTRAINT `fk_customer_id_payment` FOREIGN KEY (`CUSTOMER_ID`) REFERENCES `customers` (`CUSTOMER_ID`),
  ADD CONSTRAINT `fk_menu_id_order` FOREIGN KEY (`MENU_ID`) REFERENCES `menus` (`MENU_ID`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `fk_caterer_id_payment` FOREIGN KEY (`CATERER_ID`) REFERENCES `cater_db` (`CATERER_ID`),
  ADD CONSTRAINT `fk_customer_id_pay` FOREIGN KEY (`CUSTOMER_ID`) REFERENCES `customers` (`CUSTOMER_ID`),
  ADD CONSTRAINT `fk_order_id_payment` FOREIGN KEY (`ORDER_ID`) REFERENCES `orders` (`ORDER_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
