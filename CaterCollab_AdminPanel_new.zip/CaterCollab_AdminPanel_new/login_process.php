<?php
session_start();
include_once 'db_connection.php';

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $_SESSION['username'] = $username;
    header("Location: home.php");
    exit();
} else {
    echo "Invalid username or password";
}

$conn->close();
?>
