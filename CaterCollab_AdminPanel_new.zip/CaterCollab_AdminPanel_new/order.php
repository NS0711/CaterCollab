<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch orders
function getOrders($conn) {
    $sql = "SELECT * FROM orders";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $orders = [];
        while($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
        return $orders;
    } else {
        return [];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <a href="home.php" class="btn btn-primary" id="backBtn"><i class="fas fa-arrow-left"></i></a>
    <title>Orders Management System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <style>
       body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        #edit-del{
            color: black;
        }
        .menu {
            margin-top: 20px;
        }
        .menu {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

.menu td, .menu th {
  border: 1px solid #ddd;
  padding: 8px;
}

.menu tr:nth-child(even){background-color: white;}

.menu tr:hover {background-color: darkgray;}

.menu th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: black;
  color: white;
}
#backBtn {
            color: black;
            background-color: white;
            border-color: black;
        }
    </style>
</head>
<body>

<div class="menu">
    <h2>Orders Management System</h2><br>
    <!-- Display Orders -->
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Menu ID</th>
                        <th>Caterer ID</th>
                        <th>Customer ID</th>
                        
                        <th>Order Items</th>
                        <th>Quantity</th>
                        <th>Total Amount</th>
                        <th>Delivery Date & Time</th>
                        <th>Delivery Location</th>
                        
                        <th>Actions</th> <!-- Add a new column for actions -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch orders from the database
                    $orders = getOrders($conn);

                    // Check if orders are fetched
                    if (!empty($orders)) {
                        foreach ($orders as $order) {
                            echo "<tr>";
                            echo "<td>{$order['ORDER_ID']}</td>";
                            echo "<td>{$order['MENU_ID']}</td>";
                            echo "<td>{$order['CATERER_ID']}</td>";
                            echo "<td>{$order['CUSTOMER_ID']}</td>";
                            
                            echo "<td>{$order['ORDER_ITEMS']}</td>";
                            echo "<td>{$order['QUANTITY']}</td>";
                            echo "<td>{$order['TOTAL_AMOUNT']}</td>";
                            echo "<td>{$order['DELIVERY_DATE_TIME']}</td>";
                            echo "<td>{$order['DELIVERY_LOCATION']}</td>";
                            
                            // Add edit and delete buttons
                            echo "<td>";
                            echo "<a href='edit_order.php?id={$order['CUSTOMER_ID']}'><i class='fas fa-edit' id='edit-del'></i></a>
                            <a href='delete_corder.php?id={$order['CUSTOMER_ID']}'><i class='fas fa-trash-alt' id='edit-del'></i></a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='15'>No orders found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- Add Button 
    <div class="row">
        <div class="col-md-12">
            <a href="add_order.php" class="btn btn-success">Add Order</a>
        </div>
    </div>-->
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
