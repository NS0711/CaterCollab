<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['action']) && $_GET['action'] == 'fetch') {
    $conn = new mysqli("localhost", "username", "password", "database");
    $result = $conn->query("SELECT * FROM images");
    $images = array();
    while ($row = $result->fetch_assoc()) {
        $images[] = $row['image_path'];
    }
    $conn->close();
    header('Content-Type: application/json');
    echo json_encode($images);
}
?>
