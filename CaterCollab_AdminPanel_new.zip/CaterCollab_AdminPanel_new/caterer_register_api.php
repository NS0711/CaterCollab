<?php

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "catercollab_adminpanel";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);



header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Content-Type: application/json');


    // Check connection
    if ($conn->connect_error) {
        echo json_encode(array("success" => false, "message" => "Connection failed: " . $conn->connect_error));
        exit();
    }
    

// Check if request method is POST

    
    // Retrieve POST data
$COMPANY_NAME = $_POST['COMPANY_NAME'];
$EMAIL = $_POST['EMAIL'];
$PASSWORD = $_POST['PASSWORD'];
$PHN_NO = $_POST['PHN_NO'];
$LINE1_ADDRESS = $_POST['LINE1_ADDRESS'];
$LINE2_ADDRESS = $_POST['LINE2_ADDRESS'];
$CITY = $_POST['CITY'];
$STATE = $_POST['STATE'];
$POSTAL_CODE = $_POST['POSTAL_CODE'];

    //$licenseInfo = $_POST['LICENSE_INFO'];




    // if (mysqli_connect_error()) {
    //     echo json_encode(array("success" => false, "message" => "Connection failed: " . mysqli_connect_error()));
    //     exit();
    // }
    

    // Prepare SQL statement
    $sql = "INSERT INTO caterers (COMPANY_NAME, EMAIL, PASSWORD, PHN_NO, LINE1_ADDRESS, LINE2_ADDRESS, CITY, STATE, POSTAL_CODE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssss", $COMPANY_NAME, $EMAIL, $PASSWORD, $PHN_NO, $LINE1_ADDRESS, $LINE2_ADDRESS, $city, $STATE, $POSTAL_CODE);

    // Execute the statement
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Data inserted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to insert data']);
    }

    // Close connection
    $stmt->close();
    $conn->close();
 
?>
