<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch payments
function getPayments($conn) {
    $sql = "SELECT * FROM payment";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $payments = [];
        while($row = $result->fetch_assoc()) {
            $payments[] = $row;
        }
        return $payments;
    } else {
        return [];
    }
}

// Function to delete a payment
function deletePayment($conn, $payment_id) {
    $sql = "DELETE FROM payment WHERE PAYMENT_ID = $payment_id";
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <a href="home.php" class="btn btn-primary" id="backBtn"><i class="fas fa-arrow-left"></i></a>
    <title>Payments Management System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <style>
       body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        #edit-del{
            color: black;
        }
        .payment {
            margin-top: 20px;
        }
        .payment {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

.payment td, .payment th {
  border: 1px solid #ddd;
  padding: 8px;
}

.payment tr:nth-child(even){background-color: white;}

.payment tr:hover {background-color: darkgrey;}

.payment th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: black;
  color: white;
}
#backBtn {
            color: black;
            background-color: white;
            border-color: black;
        }
    </style>
</head>
<body>

<div class="payment">
    <h2>Payments Management System</h2><br>
    <!-- Display Payments -->
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Payment ID</th>
                        <th>Customer ID</th>
                        <th>Caterer ID</th>
                        <th>Order ID</th>
                        <th>Payment Method</th>
                        
                        <th>Payment Date</th>
                        
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch payments from the database
                    $payments = getPayments($conn);

                    // Check if payments are fetched
                    if (!empty($payments)) {
                        foreach ($payments as $payment) {
                            echo "<tr>";
                            echo "<td>{$payment['PAYMENT_ID']}</td>";
                            echo "<td>{$payment['CUSTOMER_ID']}</td>";
                            echo "<td>{$payment['CATERER_ID']}</td>";
                            echo "<td>{$payment['ORDER_ID']}</td>";
                            echo "<td>{$payment['PAYMENT_METHOD']}</td>";
                            
                            echo "<td>{$payment['PAYMENT_DATE']}</td>";
                            
                            echo "<td>";
                            echo "<a href='edit_payment.php?id={$payment['CUSTOMER_ID']}'><i class='fas fa-edit' id='edit-del'></i></a>
                            <a href='delete_payment.php?id={$payment['CUSTOMER_ID']}'><i class='fas fa-trash-alt' id='edit-del'></i></a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='9'>No payments found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- <div class="row">
        <div class="col-md-12">
            <a href="add_payment.php" class="btn btn-success">Add Payment</a>
        </div>
    </div> -->
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
