<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch menus
function getMenus($conn) {
    $sql = "SELECT * FROM menus";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $menus = [];
        while($row = $result->fetch_assoc()) {
            $menus[] = $row;
        }
        return $menus;
    } else {
        return [];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menus Management System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <style>
       body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .container {
            margin-top: 20px;
        }
        #add{
            float: right;
            background-color: black;
            font-size: 15px;
            color: white;
            margin: 7px;
            padding: 7px;
            border-radius: 10px;
        }
        #header{
            font-size: 30px;
            padding: 10px;
            margin: 10px;
            display: flex;
            justify-content: space-between; /* Align items horizontally */
            align-items: center; /* Align items vertically */
        }
        #edit-del{
            color: black;
        }
        .men {
            margin-top: 20px;
        }
        .men {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

.men td, .men th {
  border: 1px solid #ddd;
  padding: 8px;
}

.men tr:nth-child(even){background-color: white;}

.men tr:hover {background-color: darkgrey;}

.men th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: black;
  color: white;
}
#backBtn {
            color: black;
            background-color: white;
            border-color: black;
        }
    </style>
</head>
<body>

<div class="men">
    <div id="header">
        <a href="home.php" class="btn btn-primary" id="backBtn"><i class="fas fa-arrow-left"></i></a>
        <p>Menu Management System</p><br>
        <!-- <a href='add_menu.php'  id='add'>+ Add</a> -->
    </div>

    <!-- Display Menus -->
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Menu ID</th>
                        <th>Caterer ID</th>
                        <th>Catering Type</th>
                        <th>Catering Charges</th> <!-- Fixed the closing tag -->
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch menus from the database
                    $menus = getMenus($conn);

                    // Check if menus are fetched
                    if (!empty($menus)) {
                        foreach ($menus as $menu) {
                            echo "<tr>";
                            echo "<td>{$menu['MENU_ID']}</td>";
                            echo "<td>{$menu['CATERER_ID']}</td>";
                            echo "<td>{$menu['CATERING_TYPE']}</td>";
                            echo "<td>{$menu['CATERING_CHARGES']}</td>";
                            // Add edit and delete buttons
                            echo "<td>";
                            echo "<a href='delete_menu.php?id={$menu['MENU_ID']}'><i class='fas fa-trash-alt' id='edit-del'></i></a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No menus found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
