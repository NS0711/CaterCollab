<?php


// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Content-Type: application/json');



// Check connection
if ($conn->connect_error) {
  echo json_encode(array("success" => false, "message" => "Connection failed: " . $conn->connect_error));
  exit();
}

// Check if the request method is POST
//if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Retrieve username and password from the request
  // Check if the required POST data is set
if (isset($_POST["EMAIL"]) && isset($_POST["PASSWORD"])) {
  // Retrieve username and password from the POST data
  $EMAIL = $_POST["EMAIL"];
  $PASSWORD = $_POST["PASSWORD"];

  // Proceed with your login logic here
  // ...
} else {
  // If the required POST data is not set, return an error response
  http_response_code(400); // Bad Request
  $response = array("message" => "Invalid request data");
  echo json_encode($response);
  exit(); // Terminate the script
}

  // Prepare SQL query to fetch email IDs from customer and caterer databases
  // $sql = "SELECT EMAIL FROM customers WHERE EMAIL = '$EMAIL' AND PASSWORD = '$PASSWORD'
  //         UNION
  //         SELECT EMAIL FROM caterers WHERE EMAIL = '$EMAIL' AND PASSWORD = '$PASSWORD'";
  
  
  // Prepare SQL query to fetch email IDs from customers table
$sql_customer = "SELECT EMAIL FROM customers WHERE EMAIL = '$EMAIL' AND PASSWORD = '$PASSWORD'";

// Execute the query for customers
$result_customer = $conn->query($sql_customer);

// Check if any rows are returned for customers
if ($result_customer->num_rows > 0) {
    // Login successful for customer
    http_response_code(200);
    $response = array("message" => "Login successful", "user_type" => "customers", "EMAIL" => $EMAIL);
    echo json_encode($response);
} else {
    // If login was not successful for customer, check caterers table
    // Prepare SQL query to fetch email IDs from caterers table
    $sql_caterer = "SELECT EMAIL FROM caterers WHERE EMAIL = '$EMAIL' AND PASSWORD = '$PASSWORD'";

    // Execute the query for caterers
    $result_caterer = $conn->query($sql_caterer);

    // Check if any rows are returned for caterers
    if ($result_caterer->num_rows > 0) {
        // Login successful for caterer
        http_response_code(200);
        $response = array("message" => "Login successful", "user_type" => "caterers", "EMAIL" => $EMAIL);
        echo json_encode($response);
    } else {
        // Login failed
        http_response_code(401);
        $response = array("message" => "Invalid username or password");
        echo json_encode($response);
    }
}


  // // Execute the query
  // $result = $conn->query($sql);

  // // Check if any rows are returned
  //  if ($result->num_rows > 0) {
  //    // Login successful
  //   http_response_code(200);
  //   $response = array("message" => "Login successful", "EMAIL" => $EMAIL);
  //    echo json_encode($response);
  //  } else {
  //    // Login failed
  //    http_response_code(401);
  //    $response = array("message" => "Invalid username or password");
  //    echo json_encode($response);
  //  }
// } else {
//   // Invalid request method
//   http_response_code(405);
//   $response = array("message" => "Method Not Allowed");
//   echo json_encode($response);
// }

// Close the database connection
$conn->close();

?>
