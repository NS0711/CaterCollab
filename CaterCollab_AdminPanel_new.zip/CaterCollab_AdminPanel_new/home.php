<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <style>
        body {
            background-image: url('login6.jpeg');
            background-size: cover;
            background-position: center;
            background-color: #000000;
        }
        .container {
            margin-top: 50px;
            padding: 0;
            max-width: 1200px;
        }
        .card {
            border: none;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .card-body {
            padding: 30px;
        }
        .card-title {
            font-size: 24px;
            font-weight: bold;
        }
        .btn-primary {
            color: black;
            background-color: white;
            border-color: black;
        }
        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }
        .drawer-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            z-index: 999;
        }
        .side-panel {
            position: fixed;
            top: 0;
            left: -300px;
            width: 300px;
            height: 100%;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: left 0.3s ease;
        }
        .side-panel.active {
            left: 0;
        }
        .side-panel-content {
            padding: 20px;
        }
        .side-panel-header {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 20px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        .side-panel-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .side-panel-menu-item {
            margin-bottom: 10px;
        }
        .side-panel-menu-item a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            display: block;
        }
        .side-panel-menu-item a i {
            margin-right: 10px;
        }
        .side-panel-menu-item a:hover {
            color: #007bff;
        }
        .sub-menu {
            display: none;
            padding-left: 20px;
        }
        .side-panel-menu-item.active .sub-menu {
            display: block;
        }
    </style>
</head>
<body>

<div class="container">
    <!-- Drawer Button -->
    <button class="btn btn-primary drawer-btn" id="drawerBtn">&#9776;</button>

    <h2 style="color: white;">Welcome to Catering Management System</h2>
    <div class="row mt-5">
        <!-- Display Caterers -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Caterers</h3>
                    <p class="card-text">View and manage caterers.</p>
                    <a href="caterer.php" class="btn btn-primary">View Caterers</a>
                </div>
            </div>
        </div>
        <!-- Display Customers -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Customers</h3>
                    <p class="card-text">View and manage customers.</p>
                    <a href="customer.php" class="btn btn-primary">View Customers</a>
                </div>
            </div>
        </div>
        <!-- Display menus -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Menus</h3>
                    <p class="card-text">View and manage menus.</p>
                    <a href="menu.php" class="btn btn-primary">View Menus</a>
                </div>
            </div>
        </div>
        <!-- Display payments -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Payments</h3>
                    <p class="card-text">View and manage payments.</p>
                    <a href="payment.php" class="btn btn-primary">View Payments</a>
                </div>
            </div>
        </div>
        <!-- Display orders -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Orders</h3>
                    <p class="card-text">View and manage orders.</p>
                    <a href="order.php" class="btn btn-primary">View Orders</a>
                </div>
            </div>
        </div>
        <!-- Display feedback -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Feedback</h3>
                    <p class="card-text">View and manage feedback.</p>
                    <a href="feedback.php" class="btn btn-primary">View Feedback</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Side Panel -->
<div id="sidePanel" class="side-panel">
    <div class="container">
        <div class="side-panel-content">
            <div class="side-panel-header">CatterCollab</div>
            <ul class="side-panel-menu">
                <li class="side-panel-menu-item active">
                    <a href="home.php"><i class="fas fa-home"></i> Dashboard</a>
                </li>
                <li class="side-panel-menu-item">
                    <a href="#"><i class="fas fa-user"></i> Profile</a>
                </li>
                <li class="side-panel-menu-item">
                    <a href="caterer.php"><i class="fas fa-utensils"></i> Caterers</a>
                </li>
                <li class="side-panel-menu-item">
                    <a href="customer.php"><i class="fas fa-users"></i> Customers</a>
                </li>
                <li class="side-panel-menu-item">
                    <a href="menu.php"><i class="fas fa-book"></i> Menus</a>
                </li>
                <li class="side-panel-menu-item">
                    <a href="payment.php"><i class="fas fa-money-bill"></i> Payments</a>
                </li>
                <li class="side-panel-menu-item">
                    <a href="order.php"><i class="fas fa-clipboard-list"></i> Orders</a>
                </li>
                <li class="side-panel-menu-item">
                    <a href="feedback.php"><i class="fas fa-comment"></i> Feedback</a>
                </li>
                <li class="side-panel-menu-item">
                    <a href="total.php"><i class="fas fa-cog"></i> Users</a>
                </li>
                <li class="side-panel-menu-item">
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </li>
            </ul>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<script>
    // JavaScript to handle side panel toggle
    document.getElementById("drawerBtn").addEventListener("click", function() {
        document.getElementById("sidePanel").classList.toggle("active");
    });
</script>
</body>
</html>
