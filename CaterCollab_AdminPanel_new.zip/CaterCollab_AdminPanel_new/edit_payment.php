<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if payment ID is provided in the URL
if(isset($_GET['id'])) {
    // Sanitize the input to prevent SQL injection
    $payment_id = mysqli_real_escape_string($conn, $_GET['id']);

    // Retrieve payment details from the database
    $sql = "SELECT * FROM payment WHERE PAYMENT_ID = $payment_id";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $payment = $result->fetch_assoc();
    } else {
        echo "Payment not found.";
        exit();
    }
} else {
    echo "Payment ID not provided.";
    exit();
}

// Process form submission for updating payment details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    // Assuming form fields are named accordingly, modify if necessary
    $customer_id = $_POST['customer_id'];
    $caterer_id = $_POST['caterer_id'];
    $order_id = $_POST['order_id'];
    $payment_method = $_POST['payment_method'];
    $payment_date = $_POST['payment_date'];

    // Update payment details in the database
    $sql = "UPDATE payment SET CUSTOMER_ID = '$customer_id', CATERER_ID = '$caterer_id', ORDER_ID = '$order_id', PAYMENT_METHOD = '$payment_method', PAYMENT_DATE = '$payment_date' WHERE PAYMENT_ID = $payment_id";

    if ($conn->query($sql) === TRUE) {
        // If update is successful, redirect back to the payment list page
        header("Location: payment.php");
        exit();
    } else {
        echo "Error updating payment: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Payment</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2>Edit Payment</h2>
    <form method="post">
        <div class="form-group">
            <label for="customer_id">Customer ID:</label>
            <input type="text" class="form-control" id="customer_id" name="customer_id" value="<?php echo $payment['CUSTOMER_ID']; ?>">
        </div>
        <div class="form-group">
            <label for="caterer_id">Caterer ID:</label>
            <input type="text" class="form-control" id="caterer_id" name="caterer_id" value="<?php echo $payment['CATERER_ID']; ?>">
        </div>
        <div class="form-group">
            <label for="order_id">Order ID:</label>
            <input type="text" class="form-control" id="order_id" name="order_id" value="<?php echo $payment['ORDER_ID']; ?>">
        </div>
        <div class="form-group">
            <label for="payment_method">Payment Method:</label>
            <input type="text" class="form-control" id="payment_method" name="payment_method" value="<?php echo $payment['PAYMENT_METHOD']; ?>">
        </div>
        <div class="form-group">
            <label for="payment_date">Payment Date:</label>
            <input type="text" class="form-control" id="payment_date" name="payment_date" value="<?php echo $payment['PAYMENT_DATE']; ?>">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
