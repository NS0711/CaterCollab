<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-image: url('login6.jpeg');
            background-size: cover;
            background-position: center;
            background-color: #000000;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 800px;
            height: 600px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #ffffff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
        }

        .login-container {
            flex: 1;
            padding-right: 20px;
        }

        h2 {
            color: #333333;
            text-align: center;
            margin-bottom: 30px;
        }

        .form-group label {
            color: black;
            font-weight: 600;
        }

        .form-control {
            border-color: #cccccc;
            border-radius: 5px;
            color: #333333;
        }

        .btn-primary {
            background-color: black;
            border-color: #007bff;
            width: 100%;
            border-radius: 5px;
            margin-top: 20px;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        p {
            margin-top: 7px;
            text-align: center;
            color: #666666;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            color: #0056b3;
            text-decoration: underline;
        }

        .error-message {
            color: #dc3545;
            font-size: 0.9rem;
            margin-top: 5px;
        }

        .welcome-box {
            background-image: url('login3.jpeg');
            background-size: cover; 
            background-position: center;
            flex: 1;
            background-color: #007bff;
            color: #ffffff;
            border-radius: 8px;
            padding: 20px;
        }

        .welcome-text {
            font-size: 24px;
            text-align: center;
            color: #ff9900; /* Change color to orange */
            font-weight: bold; /* Make it bold */
            font-style: italic; /* Italicize the text */
        }
        .welcome-box-text{

        }
        .login-container {
            background-image: url('login5.jpeg');
            background-size: cover;
            background-position: center;
           
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-container">
        <br>
        <br>
        
        <!-- <h2 style="color:black;"><img src="logo1.png" alt="Logo" style="height: 50px; width: 80px; border-color: black; border-radius: 8px; vertical-align: middle;"></h2> -->
            <h2 style="color:black; font-size: 40px;">Login</h2>
            <form id="loginForm" action="login_process.php" method="post" onsubmit="return validateForm()">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="form-group form-check">
                    <input type="checkbox" class="form-check-input" id="rememberMe">
                    <label class="form-check-label" for="rememberMe" style="color: black;">Remember me</label>
                </div>
                <br>
                <br>
                <button type="submit" class="btn btn-primary">Login</button>
                <p>Forgot your password? <a href="forgot_password.php" style="color: #008bff;">Reset it</a></p><br>
                <div class="welcome-box-text">
                <!-- <p style="color:#555555; font-size: 12px;">Don't have any account? <a href="register.php">Register</a></p> -->
            </div>
                <div id="errorMessage" class="error-message"></div>
            </form>
        </div>
        <div class="welcome-box">
            <!-- <div class="welcome-text"><br><br><br><br><br><br>
                <p style="color:white;">Welcome...</p>
            </div> -->
        </div>
    </div>

    <script>
        function validateForm() {
            var username = document.getElementById("username").value;
            var password = document.getElementById("password").value;
            var errorMessage = document.getElementById("errorMessage");

            if (username.trim() === "" || password.trim() === "") {
                errorMessage.innerHTML = "Please enter both username and password.";
                return false;
            }

            return true;
        }
    </script>
</body>
</html>
