<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch customers
function getCustomers($conn) {
    $sql = "SELECT * FROM customers";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $customers = [];
        while($row = $result->fetch_assoc()) {
            $customers[] = $row;
        }
        return $customers;
    } else {
        return [];
    }
}

// Function to get total number of customers
function getTotalCustomers($conn) {
    $sql = "SELECT COUNT(*) as total FROM customers";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        return $row['total'];
    } else {
        return 0;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers Management System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
     <style>
       body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .container {
            margin-top: 50px;
            padding: 0;
            max-width: 1200px;
        }
        
        #add{
            float: right;
            background-color: black;
            font-size: 15px;
            color: white;
            margin: 7px;
            padding: 7px;
            border-radius: 10px;
        }
        #header{
            font-size: 30px;
            padding: 10px;
            margin: 10px;
            display: flex;
            justify-content: space-between; /* Align items horizontally */
            align-items: center; /* Align items vertically */
        }
        #total-customers {
        margin-top: 20px;
        font-size: 24px;
        background-color: #f8f9fa;
        padding: 10px 20px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    #total-customers span {
        font-weight: bold;
        color: #333; /* Change color if needed */
    }
        #edit-del{
            color: black;
        }
        .customer {
            margin-top: 20px;
        }
        .customer {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

.customer td, .customer th {
  border: 1px solid #ddd;
  padding: 8px;
}

.customer tr:nth-child(even){background-color: white;}

.customer tr:hover {background-color: darkgrey;}

.customer th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: black;
  color: white;
}
#backBtn {
            color: black;
            background-color: white;
            border-color: black;
        }
    </style>
</head>
<body>

<div class="customer">
<div id="header">
<a href="home.php" class="btn btn-primary" id="backBtn"><i class="fas fa-arrow-left"></i></a>
        <p>Customers Management System</p>
        <a href='add_customer.php'  id='add'>+ Add</a>
    </div>
    <!-- Display Customers -->
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Customer ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Line1 Address</th>
                        <th>Line2 Address</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Postal Code</th>
                        <th>Phn. no.</th>
                        <th>Actions</th> <!-- Add a new column for actions -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch customers from the database
                    $customers = getCustomers($conn);

                    // Check if customers are fetched
                    if (!empty($customers)) {
                        foreach ($customers as $customer) {
                            echo "<tr>";
                            echo "<td>{$customer['CUSTOMER_ID']}</td>";
                            echo "<td>{$customer['NAME']}</td>";
                            echo "<td>{$customer['EMAIL']}</td>";
                            echo "<td>{$customer['PASSWORD']}</td>";
                            echo "<td>{$customer['LINE1_ADDRESS']}</td>";
                            echo "<td>{$customer['LINE2_ADDRESS']}</td>";
                            echo "<td>{$customer['CITY']}</td>";
                            echo "<td>{$customer['STATE']}</td>";
                            echo "<td>{$customer['POSTAL_CODE']}</td>";
                            echo "<td>{$customer['PHN_NO']}</td>";
                            // Add edit and delete buttons
                            echo "<td>";
        
                            echo "<a href='edit_customer.php?id={$customer['CUSTOMER_ID']}'><i class='fas fa-edit' id='edit-del'></i></a>
                            <a href='delete_customer.php?id={$customer['CUSTOMER_ID']}'><i class='fas fa-trash-alt' id='edit-del'></i></a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='11'>No customers found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            <?php
            // Display total number of customers
            $totalCustomers = getTotalCustomers($conn);
            echo "<p id='total-customers'>Total CUSTOMERS: $totalCustomers</p>";
            ?>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
