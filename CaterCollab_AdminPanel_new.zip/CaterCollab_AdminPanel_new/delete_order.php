<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if ID parameter is set and not empty
if(isset($_GET['id']) && !empty($_GET['id'])) {
    // Escape user inputs for security
    $id = $conn->real_escape_string($_GET['id']);

    // Prepare a delete statement
    $sql = "DELETE FROM orders WHERE ORDER_ID = '$id'";

    if ($conn->query($sql) === TRUE) {
        header("Location: order.php");
        
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "Invalid request. Please provide a valid order ID.";
}

// Close connection
$conn->close();
?>
