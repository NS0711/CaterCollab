<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//  fetch feedback
function getFeedback($conn) {
    $sql = "SELECT * FROM feedback";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $feedbacks = [];
        while($row = $result->fetch_assoc()) {
            $feedbacks[] = $row;
        }
        return $feedbacks;
    } else {
        return [];
    }
}

//  delete feedback
function deleteFeedback($conn, $feedback_id) {
    $sql = "DELETE FROM feedback WHERE FEEDBACK_ID = $feedback_id";
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <a href="home.php" class="btn btn-primary" id="backBtn"><i class="fas fa-arrow-left"></i></a>
    <title>Feedback Management System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Custom CSS -->
    <style>
       body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        #edit-del{
            color: black;
        }
        .fb {
            margin-top: 20px;
        }
        .fb {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

.fb td, .fb th {
  border: 1px solid #ddd;
  padding: 8px;
}

.fb tr:nth-child(even){background-color: white;}

.fb tr:hover {background-color: darkgrey;}

.fb th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: black;
  color: white;
}
#backBtn {
            color: black;
            background-color: white;
            border-color: black;
        }
    </style>
</head>
<body>

<div class="fb">
    <h2>Feedback Management System</h2><br>
    <!-- Display Feedback -->
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Feedback ID</th>
                        
                        <th>Order ID</th>
                        <th>Caterer ID</th>
                        
                        
                        <th>Customer Ratings</th>
                        <th>Customer Comment</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch feedback from the database
                    $feedbacks = getFeedback($conn);

                    // Check if feedbacks are fetched
                    if (!empty($feedbacks)) {
                        foreach ($feedbacks as $feedback) {
                            echo "<tr>";
                            echo "<td>{$feedback['FEEDBACK_ID']}</td>";
                           
                            echo "<td>{$feedback['ORDER_ID']}</td>";
                            echo "<td>{$feedback['CATERER_ID']}</td>";
                            
                            
                            echo "<td>{$feedback['CUSTOMER_RATINGS']}</td>";
                            echo "<td>{$feedback['CUSTOMER_COMMENT']}</td>";
                            
                            echo "<td>";
                            echo "<a href='delete_feedback.php?id={$feedback['FEEDBACK_ID']}'><i class='fas fa-trash-alt' id='edit-del'></i></a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='9'>No feedbacks found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- <div class="row">
        <div class="col-md-12">
            <a href="add_feedback.php" class="btn btn-success">Add Feedback</a>
        </div>
    </div> -->
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
