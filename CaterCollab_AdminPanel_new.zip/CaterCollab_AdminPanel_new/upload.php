<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['image']['tmp_name'])) {
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        $conn = new mysqli("localhost", "username", "password", "database");
        $image_path = "http://localhost/uploads/" . basename($_FILES["image"]["name"]);
        $sql = "INSERT INTO images (image_path) VALUES ('$image_path')";
        $conn->query($sql);
        $conn->close();
        echo "Image uploaded successfully";
    } else {
        echo "Failed to upload image";
    }
}
?>
