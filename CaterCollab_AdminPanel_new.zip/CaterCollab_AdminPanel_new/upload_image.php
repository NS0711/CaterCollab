<?php
// Handle image upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['image']['tmp_name'])) {
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        // Insert image path into MySQL database
        $conn = new mysqli("localhost", "username", "password", "database");
        $image_path = "http://localhost/uploads/" . basename($_FILES["image"]["name"]);
        $sql = "INSERT INTO images (image_path) VALUES ('$image_path')";
        $conn->query($sql);
        $conn->close();
        echo "Image uploaded successfully";
    } else {
        echo "Failed to upload image";
    }
}

// Handle image fetch
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['action']) && $_GET['action'] == 'fetch') {
    $conn = new mysqli("localhost", "username", "password", "database");
    $result = $conn->query("SELECT * FROM images");
    $images = array();
    while ($row = $result->fetch_assoc()) {
        $images[] = $row['image_path'];
    }
    $conn->close();
    header('Content-Type: application/json');
    echo json_encode($images);
}
?>
