<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if menu ID is provided in the URL
if(isset($_GET['id'])) {
    // Sanitize the input to prevent SQL injection
    $menu_id = mysqli_real_escape_string($conn, $_GET['id']);

    // Construct SQL DELETE statement
    $sql = "DELETE FROM menus WHERE MENU_ID = $menu_id";

    // Execute the DELETE statement
    if ($conn->query($sql) === TRUE) {
        // If deletion is successful, redirect back to the menu list page
        header("Location: menu.php");
        exit();
    } else {
        echo "Error deleting menu: " . $conn->error;
    }
} else {
    // If no menu ID is provided, redirect back to the menu list page
    header("Location: menu.php");
    exit();
}

// Close the database connection
$conn->close();
?>
