<?php
$servername = "localhost";
$username = "root"; // Change this to your actual MySQL username
$password = ""; // Change this to your actual MySQL password, or leave it empty if no password is set
$dbname = "catercollab_adminpanel"; // Change this to your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
