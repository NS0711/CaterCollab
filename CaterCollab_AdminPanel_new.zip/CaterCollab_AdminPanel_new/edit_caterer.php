<?php
include 'db_connection.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if caterer ID is provided in the URL
if(isset($_GET['id'])) {
    // Sanitize the input to prevent SQL injection
    $caterer_id = mysqli_real_escape_string($conn, $_GET['id']);

    // Retrieve caterer details from the database
    $sql = "SELECT * FROM caterers WHERE CATERER_ID = $caterer_id";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $caterer = $result->fetch_assoc();
    } else {
        echo "Caterer not found.";
        exit();
    }
} else {
    echo "Caterer ID not provided.";
    exit();
}

// Process form submission for updating caterer details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    // Assuming form fields are named accordingly, modify if necessary
    $company_name = $_POST['company_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $line1_address = $_POST['line1_address'];
    $line2_address = $_POST['line2_address'];
    $postal_code = $_POST['postal_code'];
    $phn_no = $_POST['phn_no'];

    // Update caterer details in the database
    $sql = "UPDATE caterers SET COMPANY_NAME = '$company_name', EMAIL = '$email', PASSWORD = '$password', LINE1_ADDRESS = '$line1_address', LINE2_ADDRESS = '$line2_address', POSTAL_CODE = '$postal_code', PHN_NO = '$phn_no' WHERE CATERER_ID = $caterer_id";

    if ($conn->query($sql) === TRUE) {
        // If update is successful, redirect back to the caterer list page
        header("Location: caterer.php");
        exit();
    } else {
        echo "Error updating caterer: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Caterer</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2>Edit Caterer</h2>
    <form method="post">
        <div class="form-group">
            <label for="company_name">Company Name:</label>
            <input type="text" class="form-control" id="company_name" name="company_name" value="<?php echo $caterer['COMPANY_NAME']; ?>">
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo $caterer['EMAIL']; ?>">
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" id="password" name="password" value="<?php echo $caterer['PASSWORD']; ?>">
        </div>
        <div class="form-group">
            <label for="line1_address">Line 1 Address:</label>
            <input type="text" class="form-control" id="line1_address" name="line1_address" value="<?php echo $caterer['LINE1_ADDRESS']; ?>">
        </div>
        <div class="form-group">
            <label for="line2_address">Line 2 Address:</label>
            <input type="text" class="form-control" id="line2_address" name="line2_address" value="<?php echo $caterer['LINE2_ADDRESS']; ?>">
        </div>
        <div class="form-group">
            <label for="postal_code">Postal Code:</label>
            <input type="text" class="form-control" id="postal_code" name="postal_code" value="<?php echo $caterer['POSTAL_CODE']; ?>">
        </div>
        <div class="form-group">
            <label for="phn_no">Phone Number:</label>
            <input type="text" class="form-control" id="phn_no" name="phn_no" value="<?php echo $caterer['PHN_NO']; ?>">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
