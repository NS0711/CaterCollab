<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if caterer ID is provided in the URL
if (isset($_GET['id'])) {
    $caterer_id = $_GET['id'];
    
    // Delete caterer from the database using the ID
    $delete_sql = "DELETE FROM cater_db WHERE CATERER_ID = $caterer_id";
    
    if ($conn->query($delete_sql) === TRUE) {
        echo "Caterer deleted successfully.";
    } else {
        echo "Error deleting caterer: " . $conn->error;
    }
} else {
    echo "Caterer ID not provided.";
    exit();
}
?>
