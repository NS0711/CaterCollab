<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Content-Type: application/json');

// Check connection
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }

// Check connection
if (mysqli_connect_errno()) {
    echo json_encode(array("success" => false, "message" => "Failed to connect to MySQL: " . mysqli_connect_error()));
    exit();
}


// Handle registration if the request method is POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the POST data
    $data = json_decode(file_get_contents('php://input'), true);

    // Validate the data (you should add more validation as needed)
    if (empty($data['COMPANY_NAME']) || empty($data['EMAIL']) || empty($data['PASSWORD']) || empty($data['PHN_NO']) || empty($data['LINE1_ADDRESS']) || empty($data['CITY']) || empty($data['STATE']) || empty($data['POSTAL_CODE']) || empty($data['LICENSE_INFO'])) {
        http_response_code(400); // Bad request
        echo json_encode(array('error' => 'All fields are required'));
        exit;
    }

    // Insert user data into the database
    $sql = "INSERT INTO cater_db (COMPANY_NAME, EMAIL, PASSWORD, PHN_NO, LINE1_ADDRESS, LINE2_ADDRESS, CITY, STATE, POSTAL_CODE, LICENSE_INFO) VALUES (
        '{$data['COMPANY_NAME']}', '{$data['EMAIL']}', '{$data['PASSWORD']}', '{$data['PHN_NO']}', '{$data['LINE1_ADDRESS']}', '{$data['LINE2_ADDRESS']}', '{$data['CITY']}', '{$data['STATE']}', '{$data['POSTAL_CODE']}', '{$data['LICENSE_INFO']}'
    )";

    // Check if the query was successful
    if ($conn->query($sql) === TRUE) {
        http_response_code(200); // Success
        echo json_encode(array('message' => 'User registered successfully'));
    } else {
        http_response_code(500); // Internal server error
        echo json_encode(array('error' => 'Failed to register user: ' . $conn->error));
    }
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn->close();
?>
