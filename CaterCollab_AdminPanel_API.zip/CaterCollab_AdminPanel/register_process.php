<?php
// Include database connection
include_once 'db_connection.php';

// Get form data
$username = $_POST['username'];
$password = $_POST['password'];

// Insert user into database
$sql = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
if ($conn->query($sql) === TRUE) {
    header("Location: login.php");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close database connection
$conn->close();
?>
