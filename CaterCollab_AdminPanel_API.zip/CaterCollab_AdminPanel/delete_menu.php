<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if menu ID is provided in the URL
if (isset($_GET['id'])) {
    $menu_id = $_GET['id'];
    
    // Delete menu from the database using the ID
    $delete_sql = "DELETE FROM menus WHERE MENU_ID = $menu_id";
    
    if ($conn->query($delete_sql) === TRUE) {
        echo "Menu deleted successfully.";
    } else {
        echo "Error deleting menu: " . $conn->error;
    }
} else {
    echo "Menu ID not provided.";
    exit();
}
?>
