<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to add a caterer
function addCaterer($conn, $data) {
    // Prepare SQL statement
    $sql = "INSERT INTO cater_db (COMPANY_NAME, EMAIL, PASSWORD, LINE1_ADDRESS, LINE2_ADDRESS, CITY, STATE, POSTAL_CODE, PHN_NO, LICENSE_INFO, RATINGS, CUSINE_TYPE, CANCELLATION_POLICY, MENU_LIST, LOGO_NAME) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssssssss", $data['company_name'], $data['email'], $data['password'], $data['line1_address'], $data['line2_address'], $data['city'], $data['state'], $data['postal_code'], $data['phn_no'], $data['license_info'], $data['ratings'], $data['cusine_type'], $data['cancellation_policy'], $data['menu_list'], $data['logo_name']);

    // Execute the statement
    if ($stmt->execute() === TRUE) {
        return true;
    } else {
        return "Error: " . $sql . "<br>" . $conn->error;
    }
}




// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate form data (you can add more validation)
    $company_name = $_POST['company_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $line1_address = $_POST['line1_address'];
    $line2_address = $_POST['line2_address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $postal_code = $_POST['postal_code'];
    $phn_no = $_POST['phn_no'];
    $license_info = $_POST['license_info'];
    $ratings = $_POST['ratings'];
    $availability_date = $_POST['availability_date'];
    $cusine_type = $_POST['cusine_type'];
    $cancellation_policy = $_POST['cancellation_policy'];
    $menu_list = $_POST['menu_list'];
    $logo_name = $_POST['logo_name'];

    // Add caterer to the database
    $data = array(
        'company_name' => $company_name,
        'email' => $email,
        'password' => $password,
        'line1_address' => $line1_address,
        'line2_address' => $line2_address,
        'city' => $city,
        'state' => $state,
        'postal_code' => $postal_code,
        'phn_no' => $phn_no,
        'license_info' => $license_info,
        'ratings' => $ratings,
        'availability_date' => $availability_date,
        'cusine_type' => $cusine_type,
        'cancellation_policy' => $cancellation_policy,
        'menu_list' => $menu_list,
        'logo_name' => $logo_name
    );

    $result = addCaterer($conn, $data);
    if ($result === true) {
        echo "Caterer added successfully!";
    } else {
        echo $result;
    }
}

// Close connection
$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Caterer</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Add Caterer</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <div class="form-group">
                <label for="company_name">Company Name:</label>
                <input type="text" class="form-control" id="company_name" name="company_name">
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email">
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" class="form-control" id="password" name="password">
            </div>
            <div class="form-group">
                <label for="menu_list">Menu List:</label>
                <textarea class="form-control" id="menu_list" name="menu_list"></textarea>
            </div>
            <div class="form-group">
    <label for="line1_address">Line 1 Address:</label>
    <input type="text" class="form-control" id="line1_address" name="line1_address">
</div>

<div class="form-group">
    <label for="line2_address">Line 2 Address:</label>
    <input type="text" class="form-control" id="line2_address" name="line2_address">
</div>

<div class="form-group">
    <label for="city">City:</label>
    <input type="text" class="form-control" id="city" name="city">
</div>

<div class="form-group">
    <label for="state">State:</label>
    <input type="text" class="form-control" id="state" name="state">
</div>

<div class="form-group">
    <label for="postal_code">Postal Code:</label>
    <input type="text" class="form-control" id="postal_code" name="postal_code">
</div>

<div class="form-group">
    <label for="phn_no">Phone Number:</label>
    <input type="text" class="form-control" id="phn_no" name="phn_no">
</div>

<div class="form-group">
    <label for="license_info">License Info:</label>
    <input type="text" class="form-control" id="license_info" name="license_info">
</div>

<div class="form-group">
    <label for="ratings">Ratings:</label>
    <input type="text" class="form-control" id="ratings" name="ratings">
</div>

<div class="form-group">
    <label for="availability_date">Availability Date:</label>
    <input type="date" class="form-control" id="availability_date" name="availability_date">
</div>

<div class="form-group">
    <label for="cusine_type">Cuisine Type:</label>
    <input type="text" class="form-control" id="cusine_type" name="cusine_type">
</div>

<div class="form-group">
    <label for="cancellation_policy">Cancellation Policy:</label>
    <input type="text" class="form-control" id="cancellation_policy" name="cancellation_policy">
</div>

<div class="form-group">
    <label for="menu_list">Menu List:</label>
    <textarea class="form-control" id="menu_list" name="menu_list"></textarea>
</div>

<div class="form-group">
        <label for="logo">Logo:</label>
        <input type="file" class="form-control-file" id="logo" name="logo">
    </div>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
