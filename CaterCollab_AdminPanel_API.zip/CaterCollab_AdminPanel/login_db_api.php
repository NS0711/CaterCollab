<?php

$con = mysqli_connect("localhost", "root", "", "catercollab_adminpanel");

if (mysqli_connect_errno()) {
    echo json_encode(array("status" => "error", "message" => "Failed to connect to MySQL: " . mysqli_connect_error()));
}

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header("Content-Type: application/json");

$EMAIL = $_POST['EMAIL'];
$PASSWORD = $_POST['PASSWORD'];

$sql = "SELECT * FROM customers WHERE EMAIL = '$EMAIL'";
$result = mysqli_query($con, $sql);

if ($result) {
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
            $hashedPassword = $row['PASSWORD'];
            $approval_status = $row['approval_status'];

            if (password_verify($password, $hashedPassword)) {
                if ($approval_status == 1) {
                    $CUSTOMER_ID = $row['CUSTOMER_ID'];
                    echo json_encode(array("status" => "success", "message" => "Login successful","CUSTOMER_ID" => $CUSTOMER_ID));
                } else {
                    echo json_encode(array("status" => "error", "message" => "Your account is not approved yet."));
                }
            } else {
                echo json_encode(array("status" => "error", "message" => "Invalid email or password"));
            }
    
    } else {
        echo json_encode(array("status" => "error", "message" => "User not found"));
    }
} else {
    echo json_encode(array("status" => "error", "message" => "Database error: " . mysqli_error($con)));
}


mysqli_close($con);

?>