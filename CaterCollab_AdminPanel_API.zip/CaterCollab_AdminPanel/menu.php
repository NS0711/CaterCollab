<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch menus
function getMenus($conn) {
    $sql = "SELECT * FROM menus";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $menus = [];
        while($row = $result->fetch_assoc()) {
            $menus[] = $row;
        }
        return $menus;
    } else {
        return [];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menus Management System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <style>
        /* Add your custom CSS styles here */
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .container {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Menus Management System</h2>
    <!-- Display Menus -->
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Menu ID</th>
                        <th>Menu List</th>
                        <th>Company Name</th>
                        <th>Price</th>
                        <th>Image URL</th>
                        <th>Ratings</th>
                        <th>Created Date</th>
                        <th>Updated Date</th>
                        <th>Actions</th> <!-- Add a new column for actions -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch menus from the database
                    $menus = getMenus($conn);

                    // Check if menus are fetched
                    if (!empty($menus)) {
                        foreach ($menus as $menu) {
                            echo "<tr>";
                            echo "<td>{$menu['MENU_ID']}</td>";
                            echo "<td>{$menu['MENU_LIST']}</td>";
                            echo "<td>{$menu['COMPANY_NAME']}</td>";
                            echo "<td>{$menu['PRICE']}</td>";
                            echo "<td>{$menu['IMAGE_URL']}</td>";
                            echo "<td>{$menu['RATINGS']}</td>";
                            echo "<td>{$menu['CREATED_DATE']}</td>";
                            echo "<td>{$menu['UPDATED_DATE']}</td>";
                            // Add edit and delete buttons
                            echo "<td>";
                            echo "<a href='edit_menu.php?id={$menu['MENU_ID']}' class='btn btn-primary btn-sm'>Edit</a>";
                            echo "<a href='delete_menu.php?id={$menu['MENU_ID']}' class='btn btn-danger btn-sm'>Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='9'>No menus found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- Add Button -->
    <div class="row">
        <div class="col-md-12">
            <a href="add_menu.php" class="btn btn-success">Add Menu</a>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
