<?php
// Start the session
session_start();

// Check if the user is not logged in, redirect to the login page
if (!isset($_SESSION['CATERER_ID'])) {
    header("Location: caterer_login.php");
    exit;
}

// Database connection settings
$host = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

// Connect to the database
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve all menu items for the logged-in caterer
$sql = "SELECT mi.MENU_ITEM_ID, mi.ITEM_NAME, mi.PRICE FROM menu_items mi 
        JOIN menus m ON mi.MENU_ID = m.MENU_ID 
        WHERE m.CATERER_ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['CATERER_ID']);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Menu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f2f2f2;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: black;
            color: #fff;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: black;
        }

        .logout-form {
            text-align: center;
            margin-top: 20px;
        }

        .btn-container {
            text-align: center;
        }

        .btn-container .btn {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <br>
    <h2>Menu Items</h2>
    <br>
    <table>
        <tr>
            <th>Item Name</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['ITEM_NAME']; ?></td>
            <td><?php echo $row['PRICE']; ?></td>
            <td>
                <a class="btn" href="edit_menu_item.php?item_id=<?php echo $row['MENU_ITEM_ID']; ?>">Edit</a>
                <a class="btn" href="delete_menu_item.php?item_id=<?php echo $row['MENU_ITEM_ID']; ?>">Delete</a> <!-- Delete button -->
            </td>
        </tr>
        <?php } ?>
    </table>
    <br>

    <!-- Back button to return to the previous page -->
    <div class="btn-container">
        <a class="btn" href="add_menu_page.php">To Add Menu Items</a>

        <!-- Logout button form -->
        <form class="logout-form" method="post" action="logout.php">
            <input type="submit" class="btn" value="Logout">
        </form>
    </div>
</body>
</html>

<?php
// Close the statement and database connection
$stmt->close();
$conn->close();
?>
