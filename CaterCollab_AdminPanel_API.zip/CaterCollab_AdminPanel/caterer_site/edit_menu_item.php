<?php
// Start the session
session_start();

// Check if the user is not logged in, redirect to the login page
if (!isset($_SESSION['CATERER_ID'])) {
    header("Location: caterer_login.php");
    exit;
}

// Database connection settings
$host = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

// Connect to the database
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if item_id is provided in the URL
if(isset($_GET['item_id'])) {
    $item_id = $_GET['item_id'];

    // Prepare SQL statement to retrieve menu item details
    $sql = "SELECT * FROM menu_items WHERE MENU_ITEM_ID = ? AND MENU_ID IN (SELECT MENU_ID FROM menus WHERE CATERER_ID = ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $item_id, $_SESSION['CATERER_ID']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        // Fetch the menu item details
        $row = $result->fetch_assoc();
        $item_name = $row['ITEM_NAME'];
        $price = $row['PRICE'];

        // Handle form submission for updating item name and price
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Retrieve form data
            $new_item_name = $_POST["new_item_name"];
            $new_price = $_POST["new_price"];

            // Prepare SQL statement to update item name and price
            $update_sql = "UPDATE menu_items SET ITEM_NAME = ?, PRICE = ? WHERE MENU_ITEM_ID = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("sdi", $new_item_name, $new_price, $item_id);

            // Execute the update statement
            if ($update_stmt->execute() === true) {
                // Redirect back to view menu page after successful update
                header("Location: view_menu.php");
                exit;
            } else {
                echo "Error updating item: " . $conn->error;
            }

            // Close the statement
            $update_stmt->close();
        }
    } else {
        echo "Menu item not found or does not belong to your account.";
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Menu Item</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h2 {
            margin-top: 0;
        }
        form {
            margin-top: 20px;
        }
        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"] {
            width: calc(100% - 10px);
            padding: 8px;
            margin: 5px 0 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Menu Item</h2>
        <?php if(isset($item_name) && isset($price)): ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?item_id=' . $item_id; ?>">
            <label for="new_item_name">New Item Name:</label>
            <input type="text" id="new_item_name" name="new_item_name" value="<?php echo $item_name; ?>" required>
            <br><br>
            <label for="new_price">New Price:</label>
            <input type="text" id="new_price" name="new_price" value="<?php echo $price; ?>" required>
            <br><br>
            <input type="submit" value="Update Item">
        </form>
        <?php endif; ?>
    </div>
</body>
</html>
