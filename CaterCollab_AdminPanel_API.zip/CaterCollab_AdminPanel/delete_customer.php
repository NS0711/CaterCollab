<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if customer ID is provided in the URL
if (isset($_GET['id'])) {
    $customer_id = $_GET['id'];
    
    // Delete customer from the database using the ID
    $delete_sql = "DELETE FROM customers WHERE customer_id = $customer_id";
    
    if ($conn->query($delete_sql) === TRUE) {
        echo "Customer deleted successfully.";
    } else {
        echo "Error deleting customer: " . $conn->error;
    }
} else {
    echo "Customer ID not provided.";
    exit();
}
?>
