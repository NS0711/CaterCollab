<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for adding a new menu
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $menu_list = $_POST["menu_list"];
    $company_name = $_POST["company_name"];
    $price = $_POST["price"];
    $image_url = $_POST["image_url"];
    $ratings = $_POST["ratings"];
    
    // Insert menu details into the database
    $insert_sql = "INSERT INTO menus (MENU_LIST, COMPANY_NAME, PRICE, IMAGE_URL, RATINGS)
                   VALUES ('$menu_list', '$company_name', '$price', '$image_url', '$ratings')";
    
    if ($conn->query($insert_sql) === TRUE) {
        echo "New menu added successfully.";
    } else {
        echo "Error adding menu: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Menu</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2>Add Menu</h2>
    <form method="post" action="">
        <div class="form-group">
            <label for="menu_list">Menu List:</label>
            <textarea class="form-control" id="menu_list" name="menu_list"></textarea>
        </div>
        <div class="form-group">
            <label for="company_name">Company Name:</label>
            <input type="text" class="form-control" id="company_name" name="company_name">
        </div>
        <div class="form-group">
            <label for="price">Price:</label>
            <input type="text" class="form-control" id="price" name="price">
        </div>
        <div class="form-group">
            <label for="image_url">Image URL:</label>
            <input type="text" class="form-control" id="image_url" name="image_url">
        </div>
        <div class="form-group">
            <label for="ratings">Ratings:</label>
            <input type="text" class="form-control" id="ratings" name="ratings">
        </div>
        <button type="submit" class="btn btn-primary">Add Menu</button>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
