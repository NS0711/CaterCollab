<?php
// Database configuration
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$database = "catercollab_adminpanel2"; // Your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Content-Type: application/json');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from POST request
$orderItems = json_decode($_POST['order_items'], true); // Decode JSON data

$quantity = $_POST['quantity'];
$totalAmount = $_POST['total_amount'];
$deliveryDateTime = $_POST['delivery_date_time'];
$deliveryLocation = $_POST['delivery_location'];

// Retrieve session variables
session_start();
 // Assuming you set this session variable in the login file for caterers
$customerId = $_SESSION['CUSTOMER_ID']; // Assuming you set this session variable in the login file for customers

// Prepare SQL statement
$stmt = $conn->prepare("INSERT INTO orders (MENU_ID, CATERER_ID, CUSTOMER_ID, ORDER_ITEMS, QUANTITY, TOTAL_AMOUNT, DELIVERY_DATE_TIME, DELIVERY_LOCATION) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

// Bind parameters
$stmt->bind_param("iiissdss", $menuId, $catererId, $customerId, $itemName, $quantity, $totalAmount, $deliveryDateTime, $deliveryLocation);

// Insert each order item into the database
foreach ($orderItems as $item) {
    $menuId = $item['MENU_ID'];
    $catererId = $item['CATERER_ID'];
    $itemName = $item['ITEM_NAME']; // Extract ITEM_NAME from the order item
    $stmt->execute(); // Execute the prepared statement
}

// Close statement
$stmt->close();

// Close connection
$conn->close();
?>
