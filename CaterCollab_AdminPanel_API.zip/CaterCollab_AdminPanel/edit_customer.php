<?php
// Include database connection code here
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if customer ID is provided in the URL
if (isset($_GET['id'])) {
    $customer_id = $_GET['id'];
    
    // Retrieve customer details from the database using the ID
    $sql = "SELECT * FROM customers WHERE CUSTOMER_ID = $customer_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $customer = $result->fetch_assoc();
    } else {
        echo "Customer not found.";
        exit();
    }
} else {
    echo "Customer ID not provided.";
    exit();
}

// Handle form submission for updating customer details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $line1_address = $_POST["line1_address"];
    $line2_address = $_POST["line2_address"];
    $city = $_POST["city"];
    $state = $_POST["state"];
    $postal_code = $_POST["postal_code"];
    $phn_no = $_POST["phn_no"];
    
    // Update customer details in the database
    $update_sql = "UPDATE customers SET 
        NAME='$name', 
        EMAIL='$email', 
        PASSWORD='$password', 
        LINE1_ADDRESS='$line1_address', 
        LINE2_ADDRESS='$line2_address', 
        CITY='$city', 
        STATE='$state', 
        POSTAL_CODE='$postal_code', 
        PHN_NO='$phn_no' 
        WHERE CUSTOMER_ID = $customer_id";
    
    if ($conn->query($update_sql) === TRUE) {
        echo "Customer details updated successfully.";
    } else {
        echo "Error updating customer details: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Customer</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2>Edit Customer</h2>
    <form method="post" action="">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo isset($customer['NAME']) ? $customer['NAME'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo isset($customer['EMAIL']) ? $customer['EMAIL'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" id="password" name="password" value="<?php echo isset($customer['PASSWORD']) ? $customer['PASSWORD'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="line1_address">Line1 Address:</label>
            <input type="text" class="form-control" id="line1_address" name="line1_address" value="<?php echo isset($customer['LINE1_ADDRESS']) ? $customer['LINE1_ADDRESS'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="line2_address">Line2 Address:</label>
            <input type="text" class="form-control" id="line2_address" name="line2_address" value="<?php echo isset($customer['LINE2_ADDRESS']) ? $customer['LINE2_ADDRESS'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="city">City:</label>
            <input type="text" class="form-control" id="city" name="city" value="<?php echo isset($customer['CITY']) ? $customer['CITY'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="state">State:</label>
            <input type="text" class="form-control" id="state" name="state" value="<?php echo isset($customer['STATE']) ? $customer['STATE'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="postal_code">Postal Code:</label>
            <input type="text" class="form-control" id="postal_code" name="postal_code" value="<?php echo isset($customer['POSTAL_CODE']) ? $customer['POSTAL_CODE'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="phn_no">Phone Number:</label>
            <input type="text" class="form-control" id="phn_no" name="phn_no" value="<?php echo isset($customer['PHN_NO']) ? $customer['PHN_NO'] : ''; ?>">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
