<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch customers
function getCustomers($conn) {
    $sql = "SELECT * FROM customers";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $customers = [];
        while($row = $result->fetch_assoc()) {
            $customers[] = $row;
        }
        return $customers;
    } else {
        return [];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers Management System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <style>
        /* Add your custom CSS styles here */
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .container {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Customers Management System</h2>
    <!-- Display Customers -->
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Customer ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Line1 Address</th>
                        <th>Line2 Address</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Postal Code</th>
                        <th>Phn. no.</th>
                        <th>Actions</th> <!-- Add a new column for actions -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch customers from the database
                    $customers = getCustomers($conn);

                    // Check if customers are fetched
                    if (!empty($customers)) {
                        foreach ($customers as $customer) {
                            echo "<tr>";
                            echo "<td>{$customer['CUSTOMER_ID']}</td>";
                            echo "<td>{$customer['NAME']}</td>";
                            echo "<td>{$customer['EMAIL']}</td>";
                            echo "<td>{$customer['PASSWORD']}</td>";
                            echo "<td>{$customer['LINE1_ADDRESS']}</td>";
                            echo "<td>{$customer['LINE2_ADDRESS']}</td>";
                            echo "<td>{$customer['CITY']}</td>";
                            echo "<td>{$customer['STATE']}</td>";
                            echo "<td>{$customer['POSTAL_CODE']}</td>";
                            echo "<td>{$customer['PHN_NO']}</td>";
                            // Add edit and delete buttons
                            echo "<td>";
                            echo "<a href='edit_customer.php?id={$customer['CUSTOMER_ID']}' class='btn btn-primary btn-sm'>Edit</a>";
                            echo "<a href='delete_customer.php?id={$customer['CUSTOMER_ID']}' class='btn btn-danger btn-sm'>Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='11'>No customers found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <a href="add_customer.php" class="btn btn-success">Add Customer</a>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
