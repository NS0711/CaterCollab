<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch payments
function getPayments($conn) {
    $sql = "SELECT * FROM payment";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $payments = [];
        while($row = $result->fetch_assoc()) {
            $payments[] = $row;
        }
        return $payments;
    } else {
        return [];
    }
}

// Function to delete a payment
function deletePayment($conn, $payment_id) {
    $sql = "DELETE FROM payment WHERE PAYMENT_ID = $payment_id";
    if ($conn->query($sql) === TRUE) {
        return true;
    } else {
        return false;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payments Management System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <style>
        
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .container {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Payments Management System</h2>
    <!-- Display Payments -->
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Payment ID</th>
                        <th>Customer ID</th>
                        <th>Caterer ID</th>
                        <th>Order ID</th>
                        <th>Payment Method</th>
                        <th>Payment Amount</th>
                        <th>Payment Date</th>
                        <th>Payment Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch payments from the database
                    $payments = getPayments($conn);

                    // Check if payments are fetched
                    if (!empty($payments)) {
                        foreach ($payments as $payment) {
                            echo "<tr>";
                            echo "<td>{$payment['PAYMENT_ID']}</td>";
                            echo "<td>{$payment['CUSTOMER_ID']}</td>";
                            echo "<td>{$payment['CATERER_ID']}</td>";
                            echo "<td>{$payment['ORDER_ID']}</td>";
                            echo "<td>{$payment['PAYMENT_METHOD']}</td>";
                            echo "<td>{$payment['PAYMENT_AMOUNT']}</td>";
                            echo "<td>{$payment['PAYMENT_DATE']}</td>";
                            echo "<td>{$payment['PAYMENT_STATUS']}</td>";
                            echo "<td>";
                            echo "<a href='edit_payment.php?id={$payment['PAYMENT_ID']}' class='btn btn-primary btn-sm'>Edit</a>";
                            echo "<a href='delete_payment.php?id={$payment['PAYMENT_ID']}' class='btn btn-danger btn-sm'>Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='9'>No payments found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- <div class="row">
        <div class="col-md-12">
            <a href="add_payment.php" class="btn btn-success">Add Payment</a>
        </div>
    </div> -->
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
