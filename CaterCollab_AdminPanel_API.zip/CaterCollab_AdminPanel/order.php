<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch orders
function getOrders($conn) {
    $sql = "SELECT * FROM orders";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $orders = [];
        while($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
        return $orders;
    } else {
        return [];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Management System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <style>
        /* Add your custom CSS styles here */
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .container {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Orders Management System</h2>
    <!-- Display Orders -->
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Caterer ID</th>
                        <th>Customer ID</th>
                        <th>Customer Name</th>
                        <th>Order Items</th>
                        <th>Quantity</th>
                        <th>Total Price</th>
                        <th>Delivery Date & Time</th>
                        <th>Delivery Location</th>
                        <th>Contact No</th>
                        <th>Payment Method</th>
                        <th>Order Date</th>
                        <th>Order Instruction</th>
                        <th>Order Status</th>
                        <th>Actions</th> <!-- Add a new column for actions -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch orders from the database
                    $orders = getOrders($conn);

                    // Check if orders are fetched
                    if (!empty($orders)) {
                        foreach ($orders as $order) {
                            echo "<tr>";
                            echo "<td>{$order['ORDER_ID']}</td>";
                            echo "<td>{$order['CATERER_ID']}</td>";
                            echo "<td>{$order['CUSTOMER_ID']}</td>";
                            echo "<td>{$order['CUSTOMER_NAME']}</td>";
                            echo "<td>{$order['ORDER_ITEMS']}</td>";
                            echo "<td>{$order['QUANTITY']}</td>";
                            echo "<td>{$order['TOTAL_PRICE']}</td>";
                            echo "<td>{$order['DELIVERY_DATE_TIME']}</td>";
                            echo "<td>{$order['DELIVERY_LOCATION']}</td>";
                            echo "<td>{$order['CONTACT_NO']}</td>";
                            echo "<td>{$order['PAYMENT_METHOD']}</td>";
                            echo "<td>{$order['ORDER_DATE']}</td>";
                            echo "<td>{$order['ORDER_INSTRUCTION']}</td>";
                            echo "<td>{$order['ORDER_STATUS']}</td>";
                            // Add edit and delete buttons
                            echo "<td>";
                            echo "<a href='edit_order.php?id={$order['ORDER_ID']}' class='btn btn-primary btn-sm'>Edit</a>";
                            echo "<a href='delete_order.php?id={$order['ORDER_ID']}' class='btn btn-danger btn-sm'>Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='15'>No orders found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- Add Button 
    <div class="row">
        <div class="col-md-12">
            <a href="add_order.php" class="btn btn-success">Add Order</a>
        </div>
    </div>-->
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
