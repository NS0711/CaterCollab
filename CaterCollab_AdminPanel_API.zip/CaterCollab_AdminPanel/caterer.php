<?php

include 'db_connection.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch caterers
function getCaterers($conn) {
    $sql = "SELECT * FROM cater_db";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $caterers = [];
        while($row = $result->fetch_assoc()) {
            $caterers[] = $row;
        }
        return $caterers;
    } else {
        return [];
    }
}

// Handle image upload
if(isset($_FILES["logo"]) && $_FILES["logo"]["error"] == 0) {
    $targetDir = "logo/";
    $targetFile = $targetDir . basename($_FILES["logo"]["name"]);
    if(move_uploaded_file($_FILES["logo"]["tmp_name"], $targetFile)) {
        // Assuming you have other form field values available
        // You need to populate the $data array with appropriate values
        $data = array(
            'company_name' => $_POST['company_name'],
            'email' => $_POST['email'],
            'password' => $_POST['password'],
            'line1_address' => $_POST['line1_address'],
            'line2_address' => $_POST['line2_address'],
            'city' => $_POST['city'],
            'state' => $_POST['state'],
            'postal_code' => $_POST['postal_code'],
            'phn_no' => $_POST['phn_no'],
            'license_info' => $_POST['license_info'],
            'ratings' => $_POST['ratings'],
            'cusine_type' => $_POST['cusine_type'],
            'cancellation_policy' => $_POST['cancellation_policy'],
            'menu_list' => $_POST['menu_list'],
            'logo_name' => basename($_FILES["logo"]["name"]) // Assuming the logo name is the same as the uploaded file name
        );

        // Prepare and execute the SQL statement to insert data into the database
        $insertSql = "INSERT INTO cater_db (COMPANY_NAME, EMAIL, PASSWORD, LINE1_ADDRESS, LINE2_ADDRESS, CITY, STATE, POSTAL_CODE, PHN_NO, LICENSE_INFO, RATINGS, CUSINE_TYPE, CANCELLATION_POLICY, MENU_LIST, LOGO_NAME) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertSql);
        $stmt->bind_param("sssssssssssssss", $data['company_name'], $data['email'], $data['password'], $data['line1_address'], $data['line2_address'], $data['city'], $data['state'], $data['postal_code'], $data['phn_no'], $data['license_info'], $data['ratings'], $data['cusine_type'], $data['cancellation_policy'], $data['menu_list'], $data['logo_name']);
        $stmt->execute();
        $stmt->close();
    }
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
<script>
        function onEntrypointLoaded(engineInitializer) {
            let config = {renderer: 'html'};
            engineInitializer.initializeEngine(config).then(function(appRunner) {
                appRunner.runApp();
            });
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caterers Management System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <style> 
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .container {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Caterers Management System</h2>
    <!-- Display Caterers -->
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Caterer ID</th>
                        <th>Company Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Menu List</th>
                        <th>Line1 Address</th>
                        <th>Line2 Address</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Postal Code</th>
                        <th>Phn. no.</th>
                        <th>License info</th>
                        <th>Ratings</th>
                        <th>Availability Date</th>
                        <th>Cuisine Type</th>
                        <th>Cancellation Policy</th>
                        <th>Logo</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch caterers from the database
                    $caterers = getCaterers($conn);

                    // header('Content-Type: application/json');
                    // echo json_encode($caterers);

                    // Check if caterers are fetched
                    if (!empty($caterers)) {
                        foreach ($caterers as $caterer) {
                            echo "<tr>";
                            echo "<td>{$caterer['CATERER_ID']}</td>";
                            echo "<td>{$caterer['COMPANY_NAME']}</td>";
                            echo "<td>{$caterer['EMAIL']}</td>";
                            echo "<td>{$caterer['PASSWORD']}</td>";
                            echo "<td>{$caterer['MENU_LIST']}</td>";
                            echo "<td>{$caterer['LINE1_ADDRESS']}</td>";
                            echo "<td>{$caterer['LINE2_ADDRESS']}</td>";
                            echo "<td>{$caterer['CITY']}</td>";
                            echo "<td>{$caterer['STATE']}</td>";
                            echo "<td>{$caterer['POSTAL_CODE']}</td>";
                            echo "<td>{$caterer['PHN_NO']}</td>";
                            echo "<td>{$caterer['LICENSE_INFO']}</td>";
                            echo "<td>{$caterer['RATINGS']}</td>";
                            echo "<td>{$caterer['AVALIABILITY_DATE']}</td>";
                            echo "<td>{$caterer['CUSINE_TYPE']}</td>";
                            echo "<td>{$caterer['CANCELLATION_POLICY']}</td>";
                            echo "<td><img src='logo/{$caterer['LOGO_NAME']}' alt='Logo' style='max-width: 50px; max-height: 50px;'></td>";
                            echo "<td>";
                            echo "<a href='edit_caterer.php?id={$caterer['CATERER_ID']}' class='btn btn-primary btn-sm'>Edit</a>";
                            echo "<a href='delete_caterer.php?id={$caterer['CATERER_ID']}' class='btn btn-danger btn-sm'>Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='18'>No caterers found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <a href="add_caterer.php" class="btn btn-success">Add Caterer</a>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
