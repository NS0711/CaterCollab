<?php
// Include database connection code here
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if feedback ID is provided in the URL
if (isset($_GET['id'])) {
    $feedback_id = $_GET['id'];

    // Delete feedback from the database
    $delete_sql = "DELETE FROM feedback WHERE feedback_id = $feedback_id";

    if ($conn->query($delete_sql) === TRUE) {
        echo "Feedback deleted successfully.";
    } else {
        echo "Error deleting feedback: " . $conn->error;
    }
} else {
    echo "Feedback ID not provided.";
}

// Close the database connection
$conn->close();
?>
