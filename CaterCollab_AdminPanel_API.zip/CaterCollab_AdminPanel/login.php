<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f4f4f4;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #ffffff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
        }

        .login-container {
            flex: 1;
            padding-right: 20px;
        }

        h2 {
            color: #333333;
            text-align: center;
            margin-bottom: 30px;
        }

        .form-group label {
            color: #555555;
            font-weight: 600;
        }

        .form-control {
            border-color: #cccccc;
            border-radius: 5px;
            color: #333333;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            width: 100%;
            border-radius: 5px;
            margin-top: 20px;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        p {
            margin-top: 20px;
            text-align: center;
            color: #666666;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            color: #0056b3;
            text-decoration: underline;
        }

        .error-message {
            color: #dc3545;
            font-size: 0.9rem;
            margin-top: 5px;
        }

        .welcome-box {
            flex: 1;
            background-color: #007bff;
            color: #ffffff;
            border-radius: 8px;
            padding: 20px;
        }

        .welcome-text {
            font-size: 24px;
            text-align: center;
            color: #ff9900; /* Change color to orange */
            font-weight: bold; /* Make it bold */
            font-style: italic; /* Italicize the text */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-container">
            <h2>Login</h2>
            <form id="loginForm" action="login_process.php" method="post" onsubmit="return validateForm()">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="form-group form-check">
                    <input type="checkbox" class="form-check-input" id="rememberMe">
                    <label class="form-check-label" for="rememberMe" style="color: #555555;">Remember me</label>
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
                <p>Forgot your password? <a href="forgot_password.php" style="color: #007bff;">Reset it</a></p>
                <div id="errorMessage" class="error-message"></div>
            </form>
        </div>
        <div class="welcome-box">
            <div class="welcome-text">
                <p>Welcome...</p>
            </div>
        </div>
    </div>

    <script>
        function validateForm() {
            var username = document.getElementById("username").value;
            var password = document.getElementById("password").value;
            var errorMessage = document.getElementById("errorMessage");

            if (username.trim() === "" || password.trim() === "") {
                errorMessage.innerHTML = "Please enter both username and password.";
                return false;
            }

            return true;
        }
    </script>
</body>
</html>
