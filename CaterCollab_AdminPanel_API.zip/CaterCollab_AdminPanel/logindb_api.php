<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    echo json_encode(array("success" => false, "message" => "Connection failed: " . $conn->connect_error));
    exit();
}

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the required POST data is set
    if (isset($_POST["EMAIL"]) && isset($_POST["PASSWORD"])) {
        // Retrieve username and password from the POST data
        $EMAIL = $_POST["EMAIL"];
        $PASSWORD = $_POST["PASSWORD"];

        // Prepare SQL query to fetch email IDs from customers table
        $sql_customer = "SELECT EMAIL FROM customers WHERE EMAIL = ? AND PASSWORD = ?";
        $stmt_customer = $conn->prepare($sql_customer);

        // Bind parameters and execute the statement for customers
        $stmt_customer->bind_param("ss", $EMAIL, $PASSWORD);
        $stmt_customer->execute();
        $stmt_customer->store_result();

        // Check if any rows are returned for customers
        if ($stmt_customer->num_rows > 0) {
            // Login successful for customer
            http_response_code(200);
            $response = array("message" => "Login successful", "user_type" => "customer", "EMAIL" => $EMAIL);
            echo json_encode($response);
            exit(); // Terminate the script
        }

        // Prepare SQL query to fetch email IDs from caterers table
        $sql_caterer = "SELECT EMAIL FROM caterers WHERE EMAIL = ? AND PASSWORD = ?";
        $stmt_caterer = $conn->prepare($sql_caterer);

        // Bind parameters and execute the statement for caterers
        $stmt_caterer->bind_param("ss", $EMAIL, $PASSWORD);
        $stmt_caterer->execute();
        $stmt_caterer->store_result();

        // Check if any rows are returned for caterers
        if ($stmt_caterer->num_rows > 0) {
            // Login successful for caterer
            http_response_code(200);
            $response = array("message" => "Login successful", "user_type" => "caterer", "EMAIL" => $EMAIL);
            echo json_encode($response);
            exit(); // Terminate the script
        }

        // If no rows are returned for both customers and caterers, login failed
        http_response_code(401);
        $response = array("message" => "Invalid username or password");
        echo json_encode($response);
        exit(); // Terminate the script
    } else {
        // If the required POST data is not set, return an error response
        http_response_code(400); // Bad Request
        $response = array("message" => "Invalid request data");
        echo json_encode($response);
        exit(); // Terminate the script
    }
} else {
    // Invalid request method
    http_response_code(405);
    $response = array("message" => "Method Not Allowed");
    echo json_encode($response);
    exit(); // Terminate the script
}

// Close prepared statements and the database connection
$stmt_customer->close();
$stmt_caterer->close();
$conn->close();
?>
  