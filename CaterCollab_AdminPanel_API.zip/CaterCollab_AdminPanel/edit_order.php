<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if order ID is provided in the URL
if (isset($_GET['id'])) {
    $order_id = $_GET['id'];
    
    // Retrieve order details from the database using the ID
    $sql = "SELECT * FROM orders WHERE ORDER_ID = $order_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $order = $result->fetch_assoc();
    } else {
        echo "Order not found.";
        exit();
    }
} else {
    echo "Order ID not provided.";
    exit();
}

// Handle form submission for updating order details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $caterer_id = $_POST["caterer_id"];
    $customer_id = $_POST["customer_id"];
    $customer_name = $_POST["customer_name"];
    $order_items = $_POST["order_items"];
    $quantity = $_POST["quantity"];
    $total_price = $_POST["total_price"];
    $delivery_date_time = $_POST["delivery_date_time"];
    $delivery_location = $_POST["delivery_location"];
    $contact_no = $_POST["contact_no"];
    $payment_method = $_POST["payment_method"];
    $order_date = $_POST["order_date"];
    $order_instruction = $_POST["order_instruction"];
    $order_status = $_POST["order_status"];
    
    // Update order details in the database
    $update_sql = "UPDATE orders SET 
        CATERER_ID='$caterer_id', 
        CUSTOMER_ID='$customer_id', 
        CUSTOMER_NAME='$customer_name', 
        ORDER_ITEMS='$order_items', 
        QUANTITY='$quantity', 
        TOTAL_PRICE='$total_price', 
        DELIVERY_DATE_TIME='$delivery_date_time', 
        DELIVERY_LOCATION='$delivery_location', 
        CONTACT_NO='$contact_no', 
        PAYMENT_METHOD='$payment_method', 
        ORDER_DATE='$order_date', 
        ORDER_INSTRUCTION='$order_instruction', 
        ORDER_STATUS='$order_status' 
        WHERE ORDER_ID = $order_id";
    
    if ($conn->query($update_sql) === TRUE) {
        echo "Order details updated successfully.";
    } else {
        echo "Error updating order details: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2>Edit Order</h2>
    <form method="post" action="">
        <div class="form-group">
            <label for="order_id">Order ID:</label>
            <input type="text" class="form-control" id="order_id" name="order_id" value="<?php echo isset($order['ORDER_ID']) ? $order['ORDER_ID'] : ''; ?>" readonly>
        </div>
        <div class="form-group">
            <label for="caterer_id">Caterer ID:</label>
            <input type="text" class="form-control" id="caterer_id" name="caterer_id" value="<?php echo isset($order['CATERER_ID']) ? $order['CATERER_ID'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="customer_id">Customer ID:</label>
            <input type="text" class="form-control" id="customer_id" name="customer_id" value="<?php echo isset($order['CUSTOMER_ID']) ? $order['CUSTOMER_ID'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="customer_name">Customer Name:</label>
            <input type="text" class="form-control" id="customer_name" name="customer_name" value="<?php echo isset($order['CUSTOMER_NAME']) ? $order['CUSTOMER_NAME'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="order_items">Order Items:</label>
            <input type="text" class="form-control" id="order_items" name="order_items" value="<?php echo isset($order['ORDER_ITEMS']) ? $order['ORDER_ITEMS'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="quantity">Quantity:</label>
            <input type="text" class="form-control" id="quantity" name="quantity" value="<?php echo isset($order['QUANTITY']) ? $order['QUANTITY'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="total_price">Total Price:</label>
            <input type="text" class="form-control" id="total_price" name="total_price" value="<?php echo isset($order['TOTAL_PRICE']) ? $order['TOTAL_PRICE'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="delivery_date_time">Delivery Date & Time:</label>
            <input type="text" class="form-control" id="delivery_date_time" name="delivery_date_time" value="<?php echo isset($order['DELIVERY_DATE_TIME']) ? $order['DELIVERY_DATE_TIME'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="delivery_location">Delivery Location:</label>
            <input type="text" class="form-control" id="delivery_location" name="delivery_location" value="<?php echo isset($order['DELIVERY_LOCATION']) ? $order['DELIVERY_LOCATION'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="contact_no">Contact No:</label>
            <input type="text" class="form-control" id="contact_no" name="contact_no" value="<?php echo isset($order['CONTACT_NO']) ? $order['CONTACT_NO'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="payment_method">Payment Method:</label>
            <input type="text" class="form-control" id="payment_method" name="payment_method" value="<?php echo isset($order['PAYMENT_METHOD']) ? $order['PAYMENT_METHOD'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="order_date">Order Date:</label>
            <input type="text" class="form-control" id="order_date" name="order_date" value="<?php echo isset($order['ORDER_DATE']) ? $order['ORDER_DATE'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="order_instruction">Order Instruction:</label>
            <input type="text" class="form-control" id="order_instruction" name="order_instruction" value="<?php echo isset($order['ORDER_INSTRUCTION']) ? $order['ORDER_INSTRUCTION'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="order_status">Order Status:</label>
            <input type="text" class="form-control" id="order_status" name="order_status" value="<?php echo isset($order['ORDER_STATUS']) ? $order['ORDER_STATUS'] : ''; ?>">
        </div>

        <!-- Add more form fields as needed -->
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
