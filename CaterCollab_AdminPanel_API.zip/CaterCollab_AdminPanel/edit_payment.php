<?php
// Include database connection code here
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if payment ID is provided in the URL
if (isset($_GET['id'])) {
    $payment_id = $_GET['id'];
    
    // Retrieve payment details from the database using the ID
    $sql = "SELECT * FROM payment WHERE PAYMENT_ID = $payment_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $payment = $result->fetch_assoc();
    } else {
        echo "Payment not found.";
        exit();
    }
} else {
    echo "Payment ID not provided.";
    exit();
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $customer_id = $_POST["customer_id"];
    $caterer_id = $_POST["caterer_id"];
    $order_id = $_POST["order_id"];
    $payment_method = $_POST["payment_method"];
    $payment_amount = $_POST["payment_amount"];
    $payment_date = $_POST["payment_date"];
    $payment_status = $_POST["payment_status"];
    
    // Update payment details in the database
    $update_sql = "UPDATE payment SET 
        CUSTOMER_ID='$customer_id', 
        CATERER_ID='$caterer_id', 
        ORDER_ID='$order_id', 
        PAYMENT_METHOD='$payment_method', 
        PAYMENT_AMOUNT='$payment_amount', 
        PAYMENT_DATE='$payment_date', 
        PAYMENT_STATUS='$payment_status' 
        WHERE PAYMENT_ID = $payment_id";
    
    if ($conn->query($update_sql) === TRUE) {
        echo "Payment details updated successfully.";
    } else {
        echo "Error updating payment details: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Payment</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2>Edit Payment</h2>
    <form method="post" action="">
        <div class="form-group">
            <label for="customer_id">Customer ID:</label>
            <input type="text" class="form-control" id="customer_id" name="customer_id" value="<?php echo isset($payment['CUSTOMER_ID']) ? $payment['CUSTOMER_ID'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="caterer_id">Caterer ID:</label>
            <input type="text" class="form-control" id="caterer_id" name="caterer_id" value="<?php echo isset($payment['CATERER_ID']) ? $payment['CATERER_ID'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="order_id">Order ID:</label>
            <input type="text" class="form-control" id="order_id" name="order_id" value="<?php echo isset($payment['ORDER_ID']) ? $payment['ORDER_ID'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="payment_method">Payment Method:</label>
            <input type="text" class="form-control" id="payment_method" name="payment_method" value="<?php echo isset($payment['PAYMENT_METHOD']) ? $payment['PAYMENT_METHOD'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="payment_amount">Payment Amount:</label>
            <input type="text" class="form-control" id="payment_amount" name="payment_amount" value="<?php echo isset($payment['PAYMENT_AMOUNT']) ? $payment['PAYMENT_AMOUNT'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="payment_date">Payment Date:</label>
            <input type="text" class="form-control" id="payment_date" name="payment_date" value="<?php echo isset($payment['PAYMENT_DATE']) ? $payment['PAYMENT_DATE'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="payment_status">Payment Status:</label>
            <input type="text" class="form-control" id="payment_status" name="payment_status" value="<?php echo isset($payment['PAYMENT_STATUS']) ? $payment['PAYMENT_STATUS'] : ''; ?>">
        </div>

      
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
