<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    
    <style>
        
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            border: none;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .card-body {
            padding: 30px;
        }
        .card-title {
            font-size: 24px;
            font-weight: bold;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Welcome to Catering Management System</h2>
    <div class="row mt-5">
        <!-- Display Caterers -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Caterers</h3>
                    <p class="card-text">View and manage caterers.</p>
                    <a href="caterer.php" class="btn btn-primary">View Caterers</a>
                </div>
            </div>
        </div>
        <!-- Display Customers -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Customers</h3>
                    <p class="card-text">View and manage customers.</p>
                    <a href="customer.php" class="btn btn-primary">View Customers</a>
                </div>
            </div>
        </div>
        <!-- Display menus -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Menus</h3>
                    <p class="card-text">View and manage menus.</p>
                    <a href="menu.php" class="btn btn-primary">View Menus</a>
                </div>
            </div>
        </div>
        <!-- Display payments -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Payments</h3>
                    <p class="card-text">View and manage payments.</p>
                    <a href="payment.php" class="btn btn-primary">View Payments</a>
                </div>
            </div>
        </div>
        <!-- Display orders -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Orders</h3>
                    <p class="card-text">View and manage orders.</p>
                    <a href="order.php" class="btn btn-primary">View Orders</a>
                </div>
            </div>
        </div>
        <!-- Display feedback -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Feedback</h3>
                    <p class="card-text">View and manage feedback.</p>
                    <a href="feedback.php" class="btn btn-primary">View Feedback</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
