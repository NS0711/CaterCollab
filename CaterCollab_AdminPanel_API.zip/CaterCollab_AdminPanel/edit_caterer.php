<?php
// Include database connection code here
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if caterer ID is provided in the URL
if (isset($_GET['id'])) {
    $caterer_id = $_GET['id'];
    
    // Retrieve caterer details from the database using the ID
    $sql = "SELECT * FROM cater_db WHERE CATERER_ID = $caterer_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $caterer = $result->fetch_assoc();
    } else {
        echo "Caterer not found.";
        exit();
    }
} else {
    echo "Caterer ID not provided.";
    exit();
}

// Handle form submission for updating caterer details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $company_name = $_POST["company_name"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $menu_list = $_POST["menu_list"];
    $line1_address = $_POST["line1_address"];
    $line2_address = $_POST["line2_address"];
    $city = $_POST["city"];
    $state = $_POST["state"];
    $postal_code = $_POST["postal_code"];
    $phn_no = $_POST["phn_no"];
    $license_info = $_POST["license_info"];
    $ratings = $_POST["ratings"];
    $availability_date = $_POST["availability_date"];
    $cuisine_type = $_POST["cuisine_type"];
    $cancellation_policy = $_POST["cancellation_policy"];
    
    // Update caterer details in the database
    $update_sql = "UPDATE cater_db SET 
        COMPANY_NAME='$company_name', 
        EMAIL='$email', 
        PASSWORD='$password', 
        MENU_LIST='$menu_list', 
        LINE1_ADDRESS='$line1_address', 
        LINE2_ADDRESS='$line2_address', 
        CITY='$city', 
        STATE='$state', 
        POSTAL_CODE='$postal_code', 
        PHN_NO='$phn_no', 
        LICENSE_INFO='$license_info', 
        RATINGS='$ratings', 
        AVALIABILITY_DATE='$availability_date', 
        CUSINE_TYPE='$cuisine_type', 
        CANCELLATION_POLICY='$cancellation_policy'
        MENU_LIST='$menu_list',
        LOGO_NAME = '$logo_name' 
        WHERE CATERER_ID = $caterer_id";
    
    if ($conn->query($update_sql) === TRUE) {
        echo "Caterer details updated successfully.";
        header("Location: caterer.php");
    } else {
        echo "Error updating caterer details: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Caterer</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2>Edit Caterer</h2>
    <form method="post" action="">
        <div class="form-group">
            <label for="company_name">Company Name:</label>
            <input type="text" class="form-control" id="company_name" name="company_name" value="<?php echo isset($caterer['COMPANY_NAME']) ? $caterer['COMPANY_NAME'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo isset($caterer['EMAIL']) ? $caterer['EMAIL'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" id="password" name="password" value="<?php echo isset($caterer['PASSWORD']) ? $caterer['PASSWORD'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="menu_list">Menu List:</label>
            <textarea class="form-control" id="menu_list" name="menu_list"><?php echo isset($caterer['MENU_LIST']) ? $caterer['MENU_LIST'] : ''; ?></textarea>
        </div>
        <div class="form-group">
    <label for="line1_address">Line 1 Address:</label>
    <input type="text" class="form-control" id="line1_address" name="line1_address" value="<?php echo isset($caterer['LINE1_ADDRESS']) ? $caterer['LINE1_ADDRESS'] : ''; ?>">
</div>
<div class="form-group">
    <label for="line2_address">Line 2 Address:</label>
    <input type="text" class="form-control" id="line2_address" name="line2_address" value="<?php echo isset($caterer['LINE2_ADDRESS']) ? $caterer['LINE2_ADDRESS'] : ''; ?>">
</div>
<div class="form-group">
    <label for="city">City:</label>
    <input type="text" class="form-control" id="city" name="city" value="<?php echo isset($caterer['CITY']) ? $caterer['CITY'] : ''; ?>">
</div>
<div class="form-group">
    <label for="state">State:</label>
    <input type="text" class="form-control" id="state" name="state" value="<?php echo isset($caterer['STATE']) ? $caterer['STATE'] : ''; ?>">
</div>
<div class="form-group">
    <label for="postal_code">Postal Code:</label>
    <input type="text" class="form-control" id="postal_code" name="postal_code" value="<?php echo isset($caterer['POSTAL_CODE']) ? $caterer['POSTAL_CODE'] : ''; ?>">
</div>
<div class="form-group">
    <label for="phn_no">Phone Number:</label>
    <input type="text" class="form-control" id="phn_no" name="phn_no" value="<?php echo isset($caterer['PHN_NO']) ? $caterer['PHN_NO'] : ''; ?>">
</div>
<div class="form-group">
    <label for="license_info">License Info:</label>
    <input type="text" class="form-control" id="license_info" name="license_info" value="<?php echo isset($caterer['LICENSE_INFO']) ? $caterer['LICENSE_INFO'] : ''; ?>">
</div>
<div class="form-group">
    <label for="ratings">Ratings:</label>
    <input type="text" class="form-control" id="ratings" name="ratings" value="<?php echo isset($caterer['RATINGS']) ? $caterer['RATINGS'] : ''; ?>">
</div>
<div class="form-group">
    <label for="availability_date">Availability Date:</label>
    <input type="text" class="form-control" id="availability_date" name="availability_date" value="<?php echo isset($caterer['AVALIABILITY_DATE']) ? $caterer['AVALIABILITY_DATE'] : ''; ?>">
</div>
<div class="form-group">
    <label for="cuisine_type">Cuisine Type:</label>
    <input type="text" class="form-control" id="cuisine_type" name="cuisine_type" value="<?php echo isset($caterer['CUSINE_TYPE']) ? $caterer['CUSINE_TYPE'] : ''; ?>">
</div>
<div class="form-group">
    <label for="cancellation_policy">Cancellation Policy:</label>
    <input type="text" class="form-control" id="cancellation_policy" name="cancellation_policy" value="<?php echo isset($caterer['CANCELLATION_POLICY']) ? $caterer['CANCELLATION_POLICY'] : ''; ?>">
</div>
<div class="form-group">
        <label for="logo">Logo:</label>
        <input type="file" class="form-control-file" id="logo" name="logo">
    </div>

        <!-- Add more form fields as needed -->
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
