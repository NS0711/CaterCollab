<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$connection = mysqli_connect("localhost", "root", "", "catercollab_adminpanel");

if ($connection === false) {
    die("Error: Unable to connect to the database. " . mysqli_connect_error());
}

// Check if all required fields are present
if (isset($_POST['COMPANY_NAME'], $_POST['EMAIL'], $_POST['PASSWORD'], $_POST['PHN_NO'], $_POST['LINE1_ADDRESS'])) {
    $companyName = $_POST['COMPANY_NAME'];
    $email = $_POST['EMAIL'];
    $password = $_POST['PASSWORD'];
    $phoneNumber = $_POST['PHN_NO'];
    $address = $_POST['LINE1_ADDRESS'];
    $line2Address = isset($_POST['LINE2_ADDRESS']) ? $_POST['LINE2_ADDRESS'] : null;
    $city = isset($_POST['CITY']) ? $_POST['CITY'] : null;
    $state = isset($_POST['STATE']) ? $_POST['STATE'] : null;
    $postalCode = isset($_POST['POSTAL_CODE']) ? $_POST['POSTAL_CODE'] : null;
    $imageName = isset($_POST['IMAGE_NAME']) ? $_POST['IMAGE_NAME'] : null;
    $imageData = isset($_POST['IMAGE_DATA']) ? $_POST['IMAGE_DATA'] : null;

    // Insert data into the database
    $sql = "INSERT INTO caterers (COMPANY_NAME, EMAIL, PASSWORD, PHN_NO, LINE1_ADDRESS, LINE2_ADDRESS, CITY, STATE, POSTAL_CODE, IMAGE_NAME, IMAGE_DATA) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    // Prepare and bind parameters
    $stmt = mysqli_prepare($connection, $sql);
    mysqli_stmt_bind_param($stmt, "sssssssssss", $companyName, $email, $password, $phoneNumber, $address, $line2Address, $city, $state, $postalCode, $imageName, $imageData);

    // Execute the statement
    $result = mysqli_stmt_execute($stmt);

    if ($result === false) {
        die("Error: Unable to insert data into the database. " . mysqli_error($connection));
    }

    echo json_encode(["message" => "Registration successful"]);
} else {
    echo json_encode(["error" => "Missing required fields"]);
}

mysqli_close($connection);

?>
