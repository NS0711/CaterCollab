<?php

session_start(); // Start session to persist login status

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "catercollab_adminpanel2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Content-Type: application/json');

// Check connection
if ($conn->connect_error) {
    echo json_encode(array("success" => false, "message" => "Connection failed: " . $conn->connect_error));
    exit();
}

// Check if request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve POST data
    $email = $_POST['EMAIL'];
    $password = $_POST['PASSWORD'];

    // Prepare SQL statement for caterers table
    $caterers_sql = "SELECT * FROM caterers WHERE EMAIL = ? AND PASSWORD = ?";
    $caterers_stmt = $conn->prepare($caterers_sql);
    $caterers_stmt->bind_param("ss", $email, $password);
    $caterers_stmt->execute();
    $caterers_result = $caterers_stmt->get_result();

    // Prepare SQL statement for customers table
    $customers_sql = "SELECT * FROM customers WHERE EMAIL = ? AND PASSWORD = ?";
    $customers_stmt = $conn->prepare($customers_sql);
    $customers_stmt->bind_param("ss", $email, $password);
    $customers_stmt->execute();
    $customers_result = $customers_stmt->get_result();

    // Check if user exists in either table
    if ($caterers_result->num_rows == 1) {
        // User is a caterer, set session variables accordingly if needed
        $caterer_row = $caterers_result->fetch_assoc();
    $caterer_id = $caterer_row['CATERER_ID']; // Assuming the column name is 'caterer_id'
    $_SESSION['loggedin'] = true;
    $_SESSION['email'] = $email;
    $_SESSION['CATERER_ID'] = $caterer_id;
        echo json_encode(['success' => true, 'message' => 'Login successful']);
    } elseif ($customers_result->num_rows == 1) {
        // User is a customer, retrieve customer_id and set session variables
        $customer_row = $customers_result->fetch_assoc();
        $customer_id = $customer_row['CUSTOMER_ID'];
        $_SESSION['loggedin'] = true;
        $_SESSION['email'] = $email;
        $_SESSION['CUSTOMER_ID'] = $customer_id;
        echo json_encode(['success' => true, 'message' => 'Login successful']);
    } else {
        // User not found in either table
        echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
    }

    // Close statements
    $caterers_stmt->close();
    $customers_stmt->close();
} else {
    // If request method is not POST
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

// Close connection
$conn->close();

?>
