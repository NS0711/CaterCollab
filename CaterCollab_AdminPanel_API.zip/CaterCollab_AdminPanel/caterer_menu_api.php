<?php

header("Access-Control-Allow-Origin: *"); // Allow requests from any origin
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); // Allow the specified HTTP methods
header("Access-Control-Allow-Headers: Content-Type"); // Allow the specified headers

$connection = mysqli_connect("localhost", "root", "", "catercollab_adminpanel2");

if ($connection === false) {
    die("Error: Unable to connect to database. " . mysqli_connect_error());
}

// Check if catererId is provided in the request
if (isset($_GET['catererId'])) {
    $catererId = $_GET['catererId'];

    // Fetch menu items for the specified catererId
    $sql = "SELECT * FROM menu_items
            INNER JOIN menus ON menu_items.MENU_ID = menus.MENU_ID
            WHERE menus.CATERER_ID = $catererId";

    $result = mysqli_query($connection, $sql);

    if ($result === false) {
        die("Error: Unable to fetch data. " . mysqli_error($connection));
    }

    $data = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }

    header('Content-Type: application/json');
    echo json_encode($data);
} else {
    die("Error: Caterer ID not provided.");
}

mysqli_close($connection);

?>
