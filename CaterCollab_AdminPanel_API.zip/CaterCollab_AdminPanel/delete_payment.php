<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if payment ID is set
if(isset($_GET['id'])) {
    $payment_id = $_GET['id'];

    // Delete payment from the database
    $sql = "DELETE FROM payment WHERE PAYMENT_ID = $payment_id";
    if ($conn->query($sql) === TRUE) {
        echo "Payment deleted successfully";
    } else {
        echo "Error deleting payment: " . $conn->error;
    }
} else {
    echo "Payment ID not specified";
}
?>
