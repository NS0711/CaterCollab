<?php
// Include database connection code here
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if order ID is provided in the URL
if (isset($_GET['id'])) {
    $order_id = $_GET['id'];
    
    // Delete order from the database
    $delete_sql = "DELETE FROM orders WHERE ORDER_ID = $order_id";
    
    if ($conn->query($delete_sql) === TRUE) {
        echo "Order deleted successfully.";
    } else {
        echo "Error deleting order: " . $conn->error;
    }
} else {
    echo "Order ID not provided.";
}

// // Redirect to the orders page after deletion
// header("Location: orders.php");
exit();
?>
