<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to add a customer
function addCustomer($conn, $data) {
    // Prepare SQL statement
    $sql = "INSERT INTO customers(NAME, EMAIL, PASSWORD, LINE1_ADDRESS, LINE2_ADDRESS, CITY, STATE, POSTAL_CODE, PHN_NO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssss", $data['name'], $data['email'], $data['password'], $data['line1_address'], $data['line2_address'], $data['city'], $data['state'], $data['postal_code'], $data['phn_no']);

    // Execute the statement
    if ($stmt->execute() === TRUE) {
        return true;
    } else {
        return false;
    }
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate form data (you can add more validation)
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $line1_address = $_POST['line1_address'];
    $line2_address = $_POST['line2_address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $postal_code = $_POST['postal_code'];
    $phn_no = $_POST['phn_no'];

    // Add customer to the database
    $data = array(
        'name' => $name,
        'email' => $email,
        'password' => $password,
        'line1_address' => $line1_address,
        'line2_address' => $line2_address,
        'city' => $city,
        'state' => $state,
        'postal_code' => $postal_code,
        'phn_no' => $phn_no
    );

    if (addCustomer($conn, $data)) {
        echo "Customer added successfully!";
    } else {
        echo "Error adding customer.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Customer</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <style>
        /* Add your custom CSS styles here */
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .container {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Add Customer</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <div class="form-group">
            <label for="line1_address">Address Line 1:</label>
            <input type="text" class="form-control" id="line1_address" name="line1_address" required>
        </div>
        <div class="form-group">
            <label for="line2_address">Address Line 2:</label>
            <input type="text" class="form-control" id="line2_address" name="line2_address" required>
        </div>
        <div class="form-group">
            <label for="city">City:</label>
            <input type="text" class="form-control" id="city" name="city" required>
        </div>
        <div class="form-group">
            <label for="state">State:</label>
            <input type="text" class="form-control" id="state" name="state" required>
        </div>
        <div class="form-group">
            <label for="postal_code">Postal Code:</label>
            <input type="text" class="form-control" id="postal_code" name="postal_code" required>
        </div>
        <div class="form-group">
            <label for="phn_no">Phone Number:</label>
            <input type="text" class="form-control" id="phn_no" name="phn_no" required>
        </div>
        <button type="submit" class="btn btn-primary">Add Customer</button>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
