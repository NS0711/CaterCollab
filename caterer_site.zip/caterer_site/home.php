<?php
// Start the session
session_start();

// Check if the user is not logged in, redirect to the login page
if (!isset($_SESSION['CATERER_ID'])) {
    header("Location: caterer_login.php");
    exit;
}

// Database connection settings
$host = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

// Connect to the database
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if there are any menus associated with the current caterer
$sql_check_menu = "SELECT * FROM menus WHERE CATERER_ID = ?";
$stmt_check_menu = $conn->prepare($sql_check_menu);
$stmt_check_menu->bind_param("i", $_SESSION['CATERER_ID']);
$stmt_check_menu->execute();
$result_check_menu = $stmt_check_menu->get_result();

// Check if any menus exist
$menu_exists = $result_check_menu->num_rows > 0;

// Close the statement
$stmt_check_menu->close();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && !$menu_exists) {
    // Retrieve form data
    $cateringType = $_POST["catering_type"];
    $cateringCharges = $_POST["catering_charges"];

    // Prepare SQL statement
    $sql = "INSERT INTO menus (CATERER_ID, CATERING_TYPE, CATERING_CHARGES) VALUES (?, ?, ?)";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $_SESSION['CATERER_ID'], $cateringType, $cateringCharges);

    // Execute the statement
    if ($stmt->execute() === true) {
        // Redirect to the add menu page
        header("Location: add_menu_page.php");
        exit; // Make sure to exit to prevent further execution of the script
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Menu Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h2 {
            margin-top: 0;
        }
        form {
            margin-top: 20px;
        }
        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"] {
            width: calc(100% - 10px);
            padding: 8px;
            margin: 5px 0 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"], input[type="button"] {
            background-color: black;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        input[type="submit"]:hover, input[type="button"]:hover {
            background-color: black;
        }
        p {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container"><br>
        <h2>Insert Catering Details</h2>
        <?php if (!$menu_exists) { ?>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <label for="catering_type">Catering Type:</label>
                <input type="text" id="catering_type" name="catering_type" placeholder="Wedding Caterer, Meal Box Service, Verified only*" required>
                <br><br>
                <label for="catering_charges">Catering Charges:</label>
                <input type="text" id="catering_charges" name="catering_charges" placeholder="excluding food charges*" required>
                <br><br>
                <input type="submit" value="ADD MENU Here">
            </form>
        <?php } else { ?>
            <p>You have already added catering details.</p>
        <?php } ?><br>
        <form method="post" action="edit_catering_page.php">
            <input type="submit" value="Edit Catering Details">
        </form>
        <form method="get" action="add_menu_page.php">
            <input type="submit" value="To ADD MENU Click Here">
        </form>
    </div>
</body>
</html>
