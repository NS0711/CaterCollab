<?php
// Start the session
session_start();

// Check if the user is not logged in, redirect to the login page
if (!isset($_SESSION['CATERER_ID'])) {
    header("Location: caterer_login.php");
    exit;
}

// Database connection settings
$host = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

// Connect to the database
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted for updating catering details
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update_catering"])) {
    // Retrieve form data
    $cateringType = $_POST["catering_type"];
    $cateringCharges = $_POST["catering_charges"];

    // Prepare SQL statement to update catering details
    $sql = "UPDATE menus SET CATERING_TYPE = ?, CATERING_CHARGES = ? WHERE CATERER_ID = ?";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $cateringType, $cateringCharges, $_SESSION['CATERER_ID']);

    // Execute the statement
    if ($stmt->execute() === true) {
        // Redirect to the home page
        header("Location: home.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the statement
    $stmt->close();
}

// Retrieve the current catering details from the database
$sql = "SELECT CATERING_TYPE, CATERING_CHARGES FROM menus WHERE CATERER_ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['CATERER_ID']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $cateringType = $row['CATERING_TYPE'];
    $cateringCharges = $row['CATERING_CHARGES'];
} else {
    echo "Catering details not found.";
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Catering Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        form {
            width: 100%;
            margin-top: 20px;
        }
        label {
            font-weight: bold;
            display: block;
        }
        input[type="text"] {
            width: calc(100% - 10px);
            padding: 8px;
            margin: 5px 0 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: black;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            display: block;
            margin: 15px auto 0;
        }
        input[type="submit"]:hover {
            background-color: black;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Catering Details</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="catering_type">Catering Type:</label>
            <input type="text" id="catering_type" name="catering_type" value="<?php echo $cateringType; ?>" required>
            <label for="catering_charges">Catering Charges:</label>
            <input type="text" id="catering_charges" name="catering_charges" value="<?php echo $cateringCharges; ?>" required>
            <input type="submit" name="update_catering" value="Update Catering Details">
        </form>
    </div>
</body>
</html>
