<?php
// Start the session
session_start();

// Check if the user is not logged in, redirect to the login page
if (!isset($_SESSION['CATERER_ID'])) {
    header("Location: caterer_login.php");
    exit;
}

// Database connection settings
$host = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

// Connect to the database
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $itemName = $_POST["item_name"];
    $price = $_POST["price"];

    // Prepare SQL statement to retrieve MENU_ID associated with the logged-in caterer
    $menuIdSql = "SELECT MENU_ID FROM menus WHERE CATERER_ID = ?";
    $menuIdStmt = $conn->prepare($menuIdSql);
    $menuIdStmt->bind_param("i", $_SESSION['CATERER_ID']);
    $menuIdStmt->execute();
    $menuIdResult = $menuIdStmt->get_result();
    
    if ($menuIdResult->num_rows > 0) {
        $row = $menuIdResult->fetch_assoc();
        $menuId = $row["MENU_ID"];

        // Prepare SQL statement to insert menu item
        $insertSql = "INSERT INTO menu_items (MENU_ID, ITEM_NAME, PRICE) VALUES (?, ?, ?)";
        $insertStmt = $conn->prepare($insertSql);
        $insertStmt->bind_param("iss", $menuId, $itemName, $price);

        // Execute the statement
        if ($insertStmt->execute() === true) {
            header("Location: view_menu.php");
            echo "Menu item added successfully.";
        } else {
            echo "Error: " . $insertSql . "<br>" . $conn->error;
        }
    } else {
        echo "Error: Caterer's menu not found.";
    }

    // Close the statement and database connection
    $menuIdStmt->close();
    $insertStmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Menu Items</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        form {
            width: 100%;
            margin-top: 20px;
        }
        label {
            font-weight: bold;
            display: block;
        }
        input[type="text"] {
            width: calc(100% - 10px);
            padding: 8px;
            margin: 5px 0 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"], input[type="button"] {
            background-color: black;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            display: block;
            margin: 15px auto 0;
        }
        input[type="submit"]:hover, input[type="button"]:hover {
            background-color: black;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add Menu Items Here</h2><br>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="item_name">Item Name:</label>
            <input type="text" id="item_name" name="item_name" required>
            <label for="price">Price:</label>
            <input type="text" id="price" name="price" required>
            <input type="submit" value="Add Menu Item">
        </form>
        <!-- View button to see all added menu items -->
        <form method="get" action="view_menu.php">
        <input type="submit" value="View Menu">
    </form>

    <!-- Logout button form -->
    <form method="post" action="logout.php">
        <input type="submit" value="Logout">
    </form>
    </div>
</body>
</html>
