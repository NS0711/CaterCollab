<?php
// Start the session
session_start();

// Check if the user is not logged in, redirect to the login page
if (!isset($_SESSION['CATERER_ID'])) {
    header("Location: caterer_login.php");
    exit;
}

// Check if the menu item ID is provided in the URL
if (!isset($_GET['item_id']) || !is_numeric($_GET['item_id'])) {
    // Redirect back to the view menu page if no item ID is provided
    header("Location: view_menu.php");
    exit;
}

// Database connection settings
$host = "localhost";
$username = "root";
$password = "";
$database = "catercollab_adminpanel2";

// Connect to the database
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare the SQL statement to delete the menu item
$sql = "DELETE FROM menu_items WHERE MENU_ITEM_ID = ? AND EXISTS (SELECT 1 FROM menus WHERE menu_items.MENU_ID = menus.MENU_ID AND menus.CATERER_ID = ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $_GET['item_id'], $_SESSION['CATERER_ID']);
$stmt->execute();

// Check if the menu item was successfully deleted
if ($stmt->affected_rows > 0) {
    // Redirect back to the view menu page
    header("Location: view_menu.php");
} else {
    // If the menu item was not deleted (perhaps due to permission issues), display an error message
    echo "Error deleting menu item. Please try again.";
}

// Close the statement and database connection
$stmt->close();
$conn->close();
?>
